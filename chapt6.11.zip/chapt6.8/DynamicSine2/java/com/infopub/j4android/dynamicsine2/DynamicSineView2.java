package com.infopub.j4android.dynamicsine2;
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.View;

public class DynamicSineView2 extends View {
	float second;    //몇 초 경과 했는가 , 한바퀴도는 6초가 걸린다.
	int width;
	int height;
	int maxwidth;
	int bigRadius =200;    //큰원 반지름
	float ht=6.0f;         //각도 변화량 6초에 한바퀴 회전, 6도/0.1초
	int verticalOffset=50;

	Context context;
	public DynamicSineView2(Context context) {
		super(context);
		this.context=context;
		refreshView();
	}
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		//---------------------------
		init();
		drawBigCircle(canvas);
		drawSine(canvas);
	}
	public void init(){
		width =getWidth();
		height =getHeight();
		maxwidth =Math.max(width, height);//
		//android:screenOrientation="landscape"
	}
	public void drawSmallCircle(Canvas canvas, float fx,
								float fy, float r){
		Paint circleIn = new Paint(Paint.ANTI_ALIAS_FLAG);
		circleIn.setStyle(Style.FILL);
		circleIn.setColor(Color.RED);
		canvas.drawCircle(fx, fy, r, circleIn);
	}

	public void drawBigCircle(Canvas canvas){

		Paint circleIn = new Paint(Paint.ANTI_ALIAS_FLAG);
		circleIn.setColor(Color.LTGRAY);
		canvas.drawCircle(0+ bigRadius, 0+ bigRadius +verticalOffset, bigRadius, circleIn);

		Matrix mt = new Matrix();
		//초침
		Path secondPin = new Path();
		secondPin.moveTo(0+ bigRadius, 0+ bigRadius +verticalOffset);
		secondPin.lineTo(0+bigRadius *2, 0+ bigRadius +verticalOffset);
		mt.setRotate(-1.0f*ht * second, 0+ bigRadius, 0+ bigRadius +verticalOffset);
		secondPin.transform(mt);
		Paint secondPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		secondPaint.setColor(Color.GREEN);
		secondPaint.setStyle(Style.STROKE);
		secondPaint.setStrokeWidth(3);
		//그려
		canvas.drawPath(secondPin, secondPaint);

		float rex=(float)(bigRadius *Math.cos(Math.toRadians(-1.0f*ht * second)));
		float rey=(float)(bigRadius *Math.sin(Math.toRadians(-1.0f*ht * second)));
		drawSmallCircle(canvas, rex+ bigRadius,rey+ bigRadius +verticalOffset,10);
	}
	public void drawSine(Canvas canvas){
		Path path=new Path();
		Paint paint=new Paint();
		paint.setAntiAlias(true);
		paint.setStyle(Style.STROKE);
		int step=(maxwidth -bigRadius *2)/360;  //넓이에서 원의 지름뺀다. 360 등분
		paint.setColor(Color.RED);
		paint.setStrokeWidth(4);
		path.moveTo(0+ bigRadius *2, verticalOffset+ bigRadius);
		for(int i=0; i<=second*(int)(ht); i++){
			path.lineTo(i*step+ bigRadius *2,
					(float)(bigRadius *(1-Math.sin(Math.toRadians(i)))+verticalOffset));
		}
		canvas.drawPath(path, paint);
	}

	public void clockCalc(){
		if(second>=59){   //0~59 60단위로 다시 시작
			second=0;
		}else{
			second++;     //0.1초 마다 1 증가, 6초후 한 바퀴
		}
		invalidate(); //v1
	}

	public void refreshView(){
		refreshViewHandler.sendEmptyMessageDelayed(0,100);//0.1초 후  clockCalc()
		//refreshViewHandler.sleep(100);//0.1초 후  clockCalc()
		clockCalc();// -> invalidate() -> onDraw() ->0.1초후 clockCalc()
	}

	private RefreshViewHandler refreshViewHandler
			= new RefreshViewHandler();

	class RefreshViewHandler extends Handler {
		@Override
		public void handleMessage(Message msg) {
			refreshView();
		}
		/*
		public void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}
		*/
	};
}
