package com.infopub.j4android.j4abiorythm2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.Calendar;

public class BioMainActivity extends AppCompatActivity implements View.OnClickListener{
    private static final int DATE_INPUT = 0;
    //주기 상수
    public static final int PHYSICAL = 23;
    public static final int EMOTIONAL = 28;
    public static final int INTELLECTUAL = 33;
    //콤퍼넌트-바이오리듬그래프, 텍스트뷰, 버튼, 리니어레이아웃
    private BioRhythmGraph phyGraph;
    private BioRhythmGraph emoGraph;
    private BioRhythmGraph intelGraph;
    private  LinearLayout graphLinearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bio_main);
        Button birthDatePicker=(Button)findViewById(R.id.button);
        birthDatePicker.setOnClickListener(this);
        graphLinearLayout = (LinearLayout)findViewById(R.id.biolayout);
    }
    @Override
    public void onClick(View v) {
        startActivityForResult(new Intent(v.getContext(), BioRhythmActivity.class), DATE_INPUT );
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if( requestCode == DATE_INPUT ) {
            if( resultCode == RESULT_OK ) {
                Bundle b = data.getExtras();   //Intent에서 Bundle 찾기
                int bYear=b.getInt("bYear"); //Bundle에서 getXXX(이름) 찾기
                int bMonth=b.getInt("bMonth");
                int bDay=b.getInt("bDay");
                int tYear=b.getInt("tYear");
                int tMonth=b.getInt("tMonth");
                int tDay=b.getInt("tDay");
                Calendar birth = Calendar.getInstance();
                birth.set(bYear, bMonth - 1, bDay);  //0월 ~11월,  생일
                Calendar theDay = Calendar.getInstance();
                theDay.set(tYear, tMonth - 1, tDay);  //0월 ~11월, 구하려고 하는날
                //주기에 따른 바이오그래프
                phyGraph = new BioRhythmGraph(getApplicationContext(), PHYSICAL, birth, theDay);
                emoGraph = new BioRhythmGraph(getApplicationContext(), EMOTIONAL, birth, theDay);
                intelGraph = new BioRhythmGraph(getApplicationContext(), INTELLECTUAL, birth, theDay);
                //리니어 레이아웃이 차지하는 전체 높이
                int properHeight = graphLinearLayout.getHeight() / 3;   //세개의 그래프를 위해
                Log.i("circle", "------------------------------------>" + properHeight);
                graphLinearLayout.removeAllViews();               //붙이기 전 청소
                //리니어 레이아웃에 수직 방향으로 세개의 그래프를 붙이기 위해
                phyGraph.setLayoutParams(
                        new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, properHeight));
                emoGraph.setLayoutParams(
                        new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, properHeight));
                intelGraph.setLayoutParams(
                        new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, properHeight));
                //리니어 레이아웃에 그래프 붙이기
                graphLinearLayout.addView(phyGraph);
                graphLinearLayout.addView(emoGraph);
                graphLinearLayout.addView(intelGraph);
                //그래프 그리기
                phyGraph.invalidate();
                emoGraph.invalidate();
                intelGraph.invalidate();
            }
        }
    }
}
