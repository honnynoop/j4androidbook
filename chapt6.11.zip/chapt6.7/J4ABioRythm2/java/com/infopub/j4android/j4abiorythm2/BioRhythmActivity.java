package com.infopub.j4android.j4abiorythm2;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.Calendar;

public class BioRhythmActivity extends AppCompatActivity implements  View.OnClickListener {

    //콤퍼넌트- 텍스트뷰, 버튼, 리니어레이아웃
    Button birthDatePicker, specifiedDatePicker,showbio;
    EditText txtbirthdate, txtthedate ;
    private int mYear, mMonth, mDay;
    private int bYear, bMonth, bDay;
    private int tYear, tMonth, tDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bio_rhythm);
//XML 레이아웃을 참조하여 객체를 생성
        birthDatePicker=(Button)findViewById(R.id.birthdate);
        specifiedDatePicker=(Button)findViewById(R.id.thedate);
        txtbirthdate=(EditText)findViewById(R.id.txtbirthdate);
        txtthedate=(EditText)findViewById(R.id.txtthedate);
        showbio=(Button)findViewById(R.id.showbio);

//버튼에 이벤트 등록
        birthDatePicker.setOnClickListener(this);
        specifiedDatePicker.setOnClickListener(this);
        showbio.setOnClickListener(this);
//기본으로 오늘로 설정
        Calendar c = Calendar.getInstance();    //오늘
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
    }

    @Override
    public void onClick(View v) {
        if (v == birthDatePicker) {
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {
                            // DatePickerDialog에서 입력받은 생일
                            bYear=year;
                            bMonth=monthOfYear+1;
                            bDay=dayOfMonth;
                            txtbirthdate.setText(bYear + "-" + bMonth+ "-" + bDay);
                        }
                    }, mYear, mMonth, mDay);  //DatePickerDialog , 생일을 오늘부터 찾음
            datePickerDialog.show();
        }else  if (v == specifiedDatePicker) {
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {
                            //바이오 리듬을 구하려고 하는 날, DatePickerDialog로 입력
                            tYear=year;
                            tMonth=monthOfYear+1;
                            tDay=dayOfMonth;
                            txtthedate.setText(tYear + "-" + tMonth+ "-" + tDay);
                        }
                    }, mYear, mMonth, mDay); //바이오리듬 구하려는날을 오늘부터 찾음
            datePickerDialog.show();
        }else if(v==showbio && bYear!=0 && tYear!=0){
            Bundle b =getResultInformation();
            Intent i = new Intent();
            i.putExtras(b);
            setResult(RESULT_OK, i);
            finish();
        }
    }
    public Bundle getResultInformation() {
        Bundle b = new Bundle();
        b.putInt("bYear",bYear);
        b.putInt("bMonth",bMonth);
        b.putInt("bDay",bDay);
        b.putInt("tYear",tYear);
        b.putInt("tMonth",tMonth);
        b.putInt("tDay",tDay);
        return b;
    }
}
