package com.infopub.j4android.convertcurrency1;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity   implements View.OnClickListener {
    EditText dollars;
    EditText wons;
    RadioButton dtw;
    RadioButton wtd;
    Button convert;
    EditText rateTxt;
    Button currentRatio;
    InputMethodManager inMgr;
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.activity_main);
        dollars = (EditText)this.findViewById(R.id.dollor);
        wons = (EditText)this.findViewById(R.id.won);
        rateTxt= (EditText)this.findViewById(R.id.rateTxt);
        dtw = (RadioButton)this.findViewById(R.id.dtw);
        dtw.setChecked(true);
        wtd = (RadioButton)this.findViewById(R.id.wtd);
        convert = (Button)this.findViewById(R.id.convert);
        currentRatio= (Button)this.findViewById(R.id.currentRatio);
        convert.setOnClickListener(this);
        currentRatio.setOnClickListener(this);
        inMgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    }
    public void onClick(View v) {

        if(v==convert){
            if ( dtw.isChecked()) {
                double rate=Double.parseDouble(rateTxt.getText().toString());
                convertDollarsToWons(rate);
            }else if ( wtd.isChecked()) {
                double rate=Double.parseDouble(rateTxt.getText().toString());
                convertWonsToDollars(rate);
            }
        }else{
            rateTxt.setText("1163");
        }
        inMgr.hideSoftInputFromWindow(convert.getWindowToken(), 0);// 없어지송
    }
    protected String formats(double money){
        return String.format("%1$.2f", money);
    }
    protected void convertDollarsToWons( double rates) {
        double val = Double.parseDouble(dollars.getText().toString());
        wons.setText(formats(val*rates));
    }
    protected void convertWonsToDollars( double rates) {
        double val = Double.parseDouble(wons.getText().toString());
        dollars.setText(formats(val/rates));
    }
}
