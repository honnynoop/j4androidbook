package com.infopub.j4android.convertcurrency2;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText dollars;
    EditText wons;
    RadioButton dtw;
    RadioButton wtd;
    Button convert;
    Button currentRatio;
    double rate=1168.3;
    EditText rateTxt;
    String jsonStr="";
    InputMethodManager inMgr;
    FinanceRequestAsync financeAsync;
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.activity_main);
        dollars = (EditText)this.findViewById(R.id.dollor);
        rateTxt= (EditText)this.findViewById(R.id.rateTxt);
        wons = (EditText)this.findViewById(R.id.won);
        dtw = (RadioButton)this.findViewById(R.id.dtw);
        dtw.setChecked(true);
        wtd = (RadioButton)this.findViewById(R.id.wtd);
        convert = (Button)this.findViewById(R.id.convert);
        currentRatio= (Button)this.findViewById(R.id.currentRatio);
        convert.setOnClickListener(this);
        currentRatio.setOnClickListener(this);
       inMgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        financeAsync=new FinanceRequestAsync(this);
        financeAsync.execute();
    }

    public void onClick(View v) {
        if(v==convert){
            if ( dtw.isChecked()) {  // 달라를 한화로
                double rate=Double.parseDouble(rateTxt.getText().toString());
                convertDollarsToWons(rate);
            }else if ( wtd.isChecked()) {
                double rate=Double.parseDouble(rateTxt.getText().toString());
                convertWonsToDollars(rate);
            }
        }else{
            financeAsync=new FinanceRequestAsync(this);
            financeAsync.execute();
        }

       inMgr.hideSoftInputFromWindow(convert.getWindowToken(), 0);// 없어지송
    }
    public void updateFinance( final Finance result) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                rateTxt.setText(result.krw+"");  // 1달러당 환화가치 w/$
            }
        });
    }
    protected String formats(double money){
        return String.format("%1$.2f", money);
    }
    protected void convertDollarsToWons(double rate) {
        double val = Double.parseDouble(dollars.getText().toString());
        wons.setText(formats(val*rate));
    }
    protected void convertWonsToDollars(double rate) {
        double val = Double.parseDouble(wons.getText().toString());
        dollars.setText(formats(val/rate));
    }


}