package com.infopub.j4android.convertcurrency2;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

public class FinanceRequestAsync extends AsyncTask<String, Void,Finance> {
	Activity activity;
	ProgressDialog progressDialog;
	boolean isConnection=false;

	Finance finance=new Finance();

	public FinanceRequestAsync(Activity ac){
		super();
		activity = ac;
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		progressDialog = ProgressDialog.show(activity, "Reading", "Reading Finance datas!");
	}
	@Override
	protected Finance doInBackground(String...params) {
		BufferedReader br=null;
		String newUrls1 = "https://api.fixer.io/latest?base=%s"; //가장 최신
		String base="USD";
		String newUrls=String.format(newUrls1, base);
		URL url=null;
		StringBuffer sb=new StringBuffer();
		Finance fixerRate=new Finance();
		try {
			url=new URL(newUrls); // http://api.fixer.io
			//System.out.println(newUrls);
			Log.i("FinanceRequestAsync ","doInBackground------------------"+newUrls);
			br=new BufferedReader(new InputStreamReader(url.openStream(),"utf-8"));
			String msg="";
			// http://api.fixer.io/2017-06-09?base=USD  달러 기준
			while((msg=br.readLine())!=null){
				sb.append(msg);
			}
			fixerRate = parseJSON(sb.toString(),base);
			isConnection = true;
		} catch (IOException e) {
			Log.e("HTTP Request", e.getMessage());
			isConnection = false;
		} catch (JSONException je) {
			Log.e("JSON Parser", je.getMessage());
			isConnection = false;
		}catch (Exception je) {
			Log.e("Exception ", je.getMessage());
			isConnection = false;
		}
	return fixerRate;
}
	@Override
	protected void onPostExecute(Finance result) {
		super.onPostExecute(result);
		if(isConnection) {
			if(activity instanceof MainActivity){
				((MainActivity)activity).updateFinance(result);
			}
			progressDialog.dismiss();
		} else {
			progressDialog.dismiss();
			AlertDialog.Builder adBuilder = new AlertDialog.Builder(activity);
			 
			adBuilder.setMessage("Check Http Finance Yahoo Connection and try again.")
				.setTitle("No Internet Access")
				.setPositiveButton("OK", new OnClickListener() {
			
					@Override
					public void onClick(DialogInterface dialog, int which) {
						return;
					}
				}).create();
			
			adBuilder.show();
		}
	}
	public static Finance parseJSON(String  data, String base) throws Exception{
		JSONObject jObject = new JSONObject(data);
		JSONObject rates=jObject.getJSONObject("rates");

		Finance fixerrate=new Finance();
		fixerrate.date=jObject.getString("date");
		fixerrate.base=jObject.getString("base");
		if(base.equals("USD")){
			fixerrate.usd=1.0;
			fixerrate.krw=rates.getDouble("KRW");
			fixerrate.jpy=rates.getDouble("JPY");
			fixerrate.eur=rates.getDouble("EUR");
			fixerrate.cny=rates.getDouble("CNY");
		}else if(base.equals("KRW")){
			fixerrate.usd=rates.getDouble("USD");
			fixerrate.krw=1.0;
			fixerrate.jpy=rates.getDouble("JPY");
			fixerrate.eur=rates.getDouble("EUR");
			fixerrate.cny=rates.getDouble("CNY");
		}else if(base.equals("JPY")){
			fixerrate.usd=rates.getDouble("USD");
			fixerrate.krw=rates.getDouble("KRW");
			fixerrate.jpy=1.0;
			fixerrate.eur=rates.getDouble("EUR");
			fixerrate.cny=rates.getDouble("CNY");
		}  else if(base.equals("EUR")){
			fixerrate.usd=rates.getDouble("USD");
			fixerrate.krw=rates.getDouble("KRW");
			fixerrate.jpy=rates.getDouble("JPY");
			fixerrate.eur=1.0;
			fixerrate.cny=rates.getDouble("CNY");
		} else if(base.equals("CNY")){
			fixerrate.usd=rates.getDouble("USD");
			fixerrate.krw=rates.getDouble("KRW");
			fixerrate.jpy=rates.getDouble("JPY");
			fixerrate.eur=rates.getDouble("EUR");
			fixerrate.cny=1.0;
		}
		return fixerrate;
	}
}
