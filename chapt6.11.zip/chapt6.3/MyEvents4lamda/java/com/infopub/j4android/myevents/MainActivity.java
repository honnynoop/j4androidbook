package com.infopub.j4android.myevents;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Date;

public class MainActivity extends AppCompatActivity {  // View.OnClickListener EHI
    Button birthDatePicker, specifiedDatePicker;
    EditText txtbirthdate, txtthedate ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showComponet();
    }
    public void showComponet(){
       //layout에 있는 콤퍼넌트 객체생성
        birthDatePicker=(Button)findViewById(R.id.birthdate);
        specifiedDatePicker=(Button)findViewById(R.id.thedate);
        txtbirthdate=(EditText)findViewById(R.id.txtbirthdate);
        txtthedate=(EditText)findViewById(R.id.txtthedate);
        final Button showbio=(Button)findViewById(R.id.showbio);

        //----------------------------OnClickListener
        final String temps="Hello";
/*        View.OnClickListener omylietener =new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(v==birthDatePicker){
                    MainActivity.this.txtbirthdate.setText(temps);
                }
            }
        };
        birthDatePicker.setOnClickListener( omylietener );*/
        birthDatePicker.setOnClickListener( v -> {
            if(v==birthDatePicker){
                MainActivity.this.txtbirthdate.setText(temps);
            }
        });
        //anonymous inner class
/*        specifiedDatePicker.setOnClickListener(   new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(v==specifiedDatePicker){
                    txtthedate.setText(new Date().toString());
                }
            }
        });*/
        specifiedDatePicker.setOnClickListener(
                v->{
                    if(v==specifiedDatePicker){
                        txtthedate.setText(new Date().toString());
                    }
                }
        );
        if(showbio!=null)
/*        showbio.setOnClickListener(    new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(v==showbio){
                    String st=String.format("%s! 오늘은 %s다.",txtbirthdate.getText(), txtthedate.getText());
                    txtbirthdate.setText("");
                    txtthedate.setText("");
                    Toast.makeText(getBaseContext(),st,Toast.LENGTH_LONG).show();
                }
            }
        });*/
        showbio.setOnClickListener( v->{
            if(v==showbio){
                String st=String.format("%s! 오늘은 %s다.",txtbirthdate.getText(), txtthedate.getText());
                txtbirthdate.setText("");
                txtthedate.setText("");
                Toast.makeText(getBaseContext(),st,Toast.LENGTH_LONG).show();
            }
        });
   }
}//MainActivity
