package com.infopub.j4android.myevents;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Date;
import java.util.logging.Handler;

public class MainActivity extends AppCompatActivity {
    Button birthDatePicker, specifiedDatePicker,showbio;
    EditText txtbirthdate, txtthedate ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showComponet();
    }

    public void showComponet(){
       //layout에 있는 콤퍼넌트 객체생성
        birthDatePicker=(Button)findViewById(R.id.birthdate);
        specifiedDatePicker=(Button)findViewById(R.id.thedate);
        txtbirthdate=(EditText)findViewById(R.id.txtbirthdate);
        txtthedate=(EditText)findViewById(R.id.txtthedate);
        showbio=(Button)findViewById(R.id.showbio);
        //----------------------------OnClickListener
        birthDatePicker.setOnClickListener(new MyBioClicks(txtbirthdate,  txtthedate));
        specifiedDatePicker.setOnClickListener(new MyBioClicks(txtbirthdate,  txtthedate));
        showbio.setOnClickListener(new MyBioClicks(txtbirthdate,  txtthedate));
 }
}//MainActivity
//Outer class MainActivity밖에 선언
class MyBioClicks implements View.OnClickListener{  //EHI를 MyBioClicks가 구현
    EditText txtbirthdate, txtthedate ;
    public MyBioClicks(EditText txtbirthdate, EditText txtthedate) {
        this.txtbirthdate = txtbirthdate;
        this.txtthedate = txtthedate;
    }
    @Override
    public void onClick(View v) {     //OnClickListener handler method EHM
        if(v.getId()==R.id.birthdate){
            txtbirthdate.setText("Hello");
        }else if(v.getId()==R.id.thedate){
            txtthedate.setText(new Date().toString());
        }else if(v.getId()==R.id.showbio){
            String st=String.format("%s! 오늘은 %s다.",txtbirthdate.getText(), txtthedate.getText());
            txtbirthdate.setText("");
            txtthedate.setText("");
            //v.getContext()  중요
            Toast.makeText(v.getContext(),st,Toast.LENGTH_LONG).show();
        }
    }
}