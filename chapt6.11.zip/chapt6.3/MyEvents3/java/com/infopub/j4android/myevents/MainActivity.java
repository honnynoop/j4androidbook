package com.infopub.j4android.myevents;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Date;

public class MainActivity extends AppCompatActivity {  // View.OnClickListener EHI
    Button birthDatePicker, specifiedDatePicker;
    Button showbio;
    EditText txtbirthdate, txtthedate ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showComponet();
    }
    public void showComponet(){
       //layout에 있는 콤퍼넌트 객체생성
        birthDatePicker=(Button)findViewById(R.id.birthdate);
        specifiedDatePicker=(Button)findViewById(R.id.thedate);
        txtbirthdate=(EditText)findViewById(R.id.txtbirthdate);
        txtthedate=(EditText)findViewById(R.id.txtthedate);
        showbio=(Button)findViewById(R.id.showbio);
        //----------------------------OnClickListener
        String temps="Hello";
        birthDatePicker.setOnClickListener(new MyBioClicks1(temps));      //EHL를 구현한 EHO MyBioClicks 생성
        specifiedDatePicker.setOnClickListener(new MyBioClicks2());
        showbio.setOnClickListener(new MyBioClicks3());
   }
    //Nested class MainActivity안에 선언
    class MyBioClicks1 implements View.OnClickListener{  //EHL를 MyBioClicks1이 구현
        private String hello="";
        public MyBioClicks1(String hello) {
            this.hello = hello;
        }
        @Override
        public void onClick(View v) {     //OnClickListener handler method EHM
            if(v==birthDatePicker){
                //txtbirthdate.setText(hello);
                MainActivity.this.txtbirthdate.setText(hello);  // MainActivity.this  MainActivity 멤버
            }
        }
    }
    class MyBioClicks2 implements View.OnClickListener{  //EHL를 MyBioClicks2가 구현
        @Override
        public void onClick(View v) {     //OnClickListener handler method EHM
            if(v==specifiedDatePicker){
                txtthedate.setText(new Date().toString());
            }
        }
    }
    class MyBioClicks3 implements View.OnClickListener{  //EHL를 MyBioClicks3이 구현
        @Override
        public void onClick(View v) {     //OnClickListener handler method EHM
           if(v==showbio){
                String st=String.format("%s! 오늘은 %s다.",txtbirthdate.getText(), txtthedate.getText());
                txtbirthdate.setText("");
                txtthedate.setText("");
                Toast.makeText(getBaseContext(),st,Toast.LENGTH_LONG).show();
            }
        }
    }

}//MainActivity
