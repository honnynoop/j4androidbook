package com.infopub.j4android.myevents;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Date;

public class MainActivity extends AppCompatActivity
            implements View.OnClickListener  {  // View.OnClickListener EHI
    Button birthDatePicker, specifiedDatePicker;
    Button showbio;
    EditText txtbirthdate, txtthedate ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showComponet();
    }

    public void showComponet(){
       //layout에 있는 콤퍼넌트 객체생성
        birthDatePicker=(Button)findViewById(R.id.birthdate);
        specifiedDatePicker=(Button)findViewById(R.id.thedate);
        txtbirthdate=(EditText)findViewById(R.id.txtbirthdate);
        txtthedate=(EditText)findViewById(R.id.txtthedate);
        showbio=(Button)findViewById(R.id.showbio);
        //----------------------------OnClickListener
        birthDatePicker.setOnClickListener(this);      //this -> EHI를 구현한 EHO
        specifiedDatePicker.setOnClickListener(this); //여기서는 자신이 EHI를 구현한 EHO
        showbio.setOnClickListener(this);
}

    @Override
    public void onClick(View v) {     //OnClickListener handler method EHM
        if(v==birthDatePicker){
            this.txtbirthdate.setText("Hello");
        }else if(v==specifiedDatePicker){
            txtthedate.setText(new Date().toString());
        }else if(v==showbio){
            String st=String.format("%s! 오늘은 %s다.",txtbirthdate.getText(), txtthedate.getText());
            Toast.makeText(getBaseContext(),st,Toast.LENGTH_LONG).show();
        }
    }
}
