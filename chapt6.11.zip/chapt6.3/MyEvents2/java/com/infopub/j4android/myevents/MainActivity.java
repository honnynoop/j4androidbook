package com.infopub.j4android.myevents;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Date;

public class MainActivity extends AppCompatActivity {  // View.OnClickListener EHL
    Button birthDatePicker, specifiedDatePicker;
    Button showbio;
    EditText txtbirthdate, txtthedate ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showComponet();
    }
    public void showComponet(){
       //layout에 있는 콤퍼넌트 객체생성
        birthDatePicker=(Button)findViewById(R.id.birthdate);
        specifiedDatePicker=(Button)findViewById(R.id.thedate);
        txtbirthdate=(EditText)findViewById(R.id.txtbirthdate);
        txtthedate=(EditText)findViewById(R.id.txtthedate);
        showbio=(Button)findViewById(R.id.showbio);
        //이벤트 핸들러 객체 등록
        birthDatePicker.setOnClickListener(new MyBioClicks());      //EHL를 구현한 EHO MyBioClicks 생성
        specifiedDatePicker.setOnClickListener(new MyBioClicks());
        showbio.setOnClickListener(new MyBioClicks());
   }
    // 중첩(Nested), 내부(Inner) 클래스  MainActivity안에 선언 => 멤버
     class MyBioClicks implements View.OnClickListener{  //EHI를 MyBioClicks가 구현
        @Override
        public void onClick(View v) {     //OnClickListener handler method : EHM
            if(v==birthDatePicker){
                txtbirthdate.setText("Hello");
                //MainActivity.this.txtbirthdate.setText("Hello");
            }else if(v==specifiedDatePicker){
                txtthedate.setText(new Date().toString());
            }else if(v==showbio){
                String st=String.format("%s! 오늘은 %s다.",txtbirthdate.getText(), txtthedate.getText());
                txtbirthdate.setText("");
                txtthedate.setText("");
                Toast.makeText(getBaseContext(),st,Toast.LENGTH_LONG).show();
            }
        }
    }//MyBioClicks
}//MainActivity
