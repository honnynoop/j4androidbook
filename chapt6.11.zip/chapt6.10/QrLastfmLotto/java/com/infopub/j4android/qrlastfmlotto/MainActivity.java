package com.infopub.j4android.qrlastfmlotto;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

/*
dependencies {
    ....
    compile 'com.journeyapps:zxing-android-embedded:3.5.0'
}
 gradle module app에 추가하세요.
 */
public class MainActivity extends AppCompatActivity implements  View.OnClickListener{
    Button showbio;
    Vibrator vib;
    WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showbio=(Button)findViewById(R.id.showbio);
        showbio.setOnClickListener(this);
        webView=(WebView)findViewById(R.id.webView);
        vib = (Vibrator) getSystemService(this.VIBRATOR_SERVICE);
    }
    @Override
    public void onClick(View v) {
        new IntentIntegrator(this).initiateScan();
    }
    public void makeToast(String str){
        Toast.makeText(this, str , Toast.LENGTH_LONG).show();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(result != null) {
            if(result.getContents() != null) {
                vib.vibrate(300);
                String contents=result.getContents();
                Log.i("WebActivity","1-------------------------------------------------"+contents);
                //contents=contents.substring(contents.lastIndexOf("/")+1);
                //contents="https://www.youtube.com/results?search_query="+contents;
                WebSettings webSettings=webView.getSettings();
                webSettings.setJavaScriptEnabled(true);
                webView.setWebViewClient(new WebViewClient());
                Log.i("WebActivity","p-------------------------------------------------"+contents);
                webView.loadUrl(contents);
                makeToast(contents);
            }else{
                makeToast("잘못된 URL입니다. QR코드를 다시 확인하세요.");
            }
        }
    }
}
