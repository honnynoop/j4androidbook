package com.infopub.j4android.basicpic;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

public class SineCurveView  extends View {
	private int verticalCenter;
	private int verticalOffset;
	private int period;
	private float dayUnit;
	private int height;
	private int horizontalCenter;
	public SineCurveView(Context context) {
		super(context);
	}
	public void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		drawAxis(canvas);
		makeGraph(canvas);
	}
	private void drawAxis(Canvas canvas) {
		setBackgroundColor(Color.WHITE);//배경색
		//setBackgroundColor(Color.BLACK);//배경색
		Paint paint = new Paint();
		Path path = new Path();
		//paint.setColor(Color.WHITE);  //선은 흰색
		paint.setColor(Color.BLACK);  //선은 흰색
		paint.setAntiAlias(true);//부드럽게연결
		paint.setStrokeWidth(3);//선의 두께 3px
		paint.setStyle(Paint.Style.STROKE);//실선
		verticalOffset = 30;
		height = getHeight() - verticalOffset;//420-30=390
		height/=3; //1/3 130
		verticalCenter = height / 2; //65
		period = getWidth();   //width 300
		dayUnit = period / 12; // 300/12=25
		horizontalCenter=period/2;
		//옆으로 center line
		path.moveTo(0, verticalCenter+verticalOffset);
		path.lineTo(period, verticalCenter+verticalOffset);
		canvas.drawPath(path, paint);
		//옆으로 upper horizontal
		path.moveTo(0, verticalOffset);
		path.lineTo(period, verticalOffset);
		canvas.drawPath(path, paint);
		//옆으로 under horizontal
		path.moveTo(0, height+verticalOffset);
		path.lineTo(period, height+verticalOffset);
		canvas.drawPath(path, paint);

		//위에서 아래로 30도 단위
		for(int i = 0; i <= period ; i+= dayUnit) {
			path.moveTo(i, verticalOffset);
			path.lineTo(i, height+verticalOffset);
		}
		canvas.drawPath(path, paint);
		//위에서 아래로 중앙선
		/*
		path = new Path();
		paint.setColor(Color.YELLOW);
		path.moveTo(horizontalCenter, verticalOffset);
		path.lineTo(horizontalCenter, height+verticalOffset);
		canvas.drawPath(path, paint);
*/
	}
	private double getBioRhythmValue(float n) {
		return verticalCenter*Math.sin(Math.toRadians(n));
	}

	public void makeGraph(Canvas canvas) {
		Path path = new Path();
		Paint paint = new Paint();
		paint.setAntiAlias(true);//부드럽게연결
		paint.setStrokeWidth(3);//선의 두께 3px
		paint.setStyle(Paint.Style.STROKE);//실선
		paint.setColor(Color.RED);

		path.moveTo(0, -(float)getBioRhythmValue(0)
				+verticalCenter+verticalOffset);
		for(int i = 0; i <= 360; i++) {
			path.lineTo(i*(dayUnit/30.0f),
			-(float)getBioRhythmValue(i)
			+verticalCenter+verticalOffset);
		}
		canvas.drawPath(path, paint);
	}
}
