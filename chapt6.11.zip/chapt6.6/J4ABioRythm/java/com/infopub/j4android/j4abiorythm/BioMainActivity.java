package com.infopub.j4android.j4abiorythm;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TimePicker;

import java.util.Calendar;
//Activity가 onClick() 이벤트 핸들러 메서드를 구현한다고 선언
public class BioMainActivity extends AppCompatActivity implements  View.OnClickListener {
    //주기 상수
    public static final int PHYSICAL = 23;
    public static final int EMOTIONAL = 28;
    public static final int INTELLECTUAL = 33;
    //콤퍼넌트-바이오리듬그래프, 텍스트뷰, 버튼, 리니어레이아웃
    private BioRhythmGraph phyGraph;
    private BioRhythmGraph emoGraph;
    private BioRhythmGraph intelGraph;
    Button birthDatePicker, specifiedDatePicker,showbio;
    EditText txtbirthdate, txtthedate ;
    private int mYear, mMonth, mDay;
    private int bYear, bMonth, bDay;
    private int tYear, tMonth, tDay;
    private  LinearLayout graphLinearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bio_main);              //XML 레이아웃
//XML 레이아웃을 참조하여 객체를 생성
        birthDatePicker=(Button)findViewById(R.id.birthdate);
        specifiedDatePicker=(Button)findViewById(R.id.thedate);
        txtbirthdate=(EditText)findViewById(R.id.txtbirthdate);
        txtthedate=(EditText)findViewById(R.id.txtthedate);
        showbio=(Button)findViewById(R.id.showbio);
        graphLinearLayout = (LinearLayout)findViewById(R.id.biolayout);
//버튼에 이벤트 등록
        birthDatePicker.setOnClickListener(this);
        specifiedDatePicker.setOnClickListener(this);
        showbio.setOnClickListener(this);
//기본으로 오늘로 설정
        Calendar c = Calendar.getInstance();    //오늘
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
    }

    @Override
    public void onClick(View v) {
        if (v == birthDatePicker) {
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {
                            // DatePickerDialog에서 입력받은 생일
                            bYear=year;
                            bMonth=monthOfYear+1;
                            bDay=dayOfMonth;
                            txtbirthdate.setText(bYear + "-" + bMonth+ "-" + bDay);
                        }
                    }, mYear, mMonth, mDay);  //DatePickerDialog , 생일을 오늘부터 찾음
            datePickerDialog.show();
        }else  if (v == specifiedDatePicker) {
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {
                            //바이오 리듬을 구하려고 하는 날, DatePickerDialog로 입력
                            tYear=year;
                            tMonth=monthOfYear+1;
                            tDay=dayOfMonth;
                            txtthedate.setText(tYear + "-" + tMonth+ "-" + tDay);
                        }
                    }, mYear, mMonth, mDay); //바이오리듬 구하려는날을 오늘부터 찾음
            datePickerDialog.show();
        }else if(v==showbio && bYear!=0 && tYear!=0){

            Calendar birth=Calendar.getInstance();
            birth.set(bYear,bMonth-1,bDay);  //0월 ~11월,  생일
            Calendar theDay=Calendar.getInstance();
            theDay.set(tYear,tMonth-1,tDay);  //0월 ~11월, 구하려고 하는날
            //주기에 따른 바이오그래프
            phyGraph=new BioRhythmGraph(getApplicationContext() ,PHYSICAL, birth ,theDay);
            emoGraph=new BioRhythmGraph(getApplicationContext() ,EMOTIONAL, birth ,theDay);
            intelGraph=new BioRhythmGraph(getApplicationContext() ,INTELLECTUAL, birth ,theDay);
            //리니어 레이아웃이 차지하는 전체 높이
            int properHeight = graphLinearLayout.getHeight() / 3;   //세개의 그래프를 위해
            Log.i("circle","------------------------------------>"+properHeight );
            graphLinearLayout.removeAllViews();               //붙이기 전 청소
            //리니어 레이아웃에 수직 방향으로 세개의 그래프를 붙이기 위해
            phyGraph.setLayoutParams(
                    new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, properHeight));
            emoGraph.setLayoutParams(
                    new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, properHeight));
            intelGraph.setLayoutParams(
                    new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, properHeight));
            //리니어 레이아웃에 그래프 붙이기
            graphLinearLayout.addView(phyGraph);
            graphLinearLayout.addView(emoGraph);
            graphLinearLayout.addView(intelGraph);
            //그래프 그리기
            phyGraph.invalidate();
            emoGraph.invalidate();
            intelGraph.invalidate();
        }
    }
}
