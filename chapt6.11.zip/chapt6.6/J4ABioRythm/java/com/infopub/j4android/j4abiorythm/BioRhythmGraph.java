package com.infopub.j4android.j4abiorythm;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

import java.util.Calendar;

public class BioRhythmGraph extends View {
	//(1) 상수에서 살펴봄 ,신체지수, 감정지수, 지성지수
	public static final int PHYSICAL = 23;
	public static final int EMOTIONAL = 28;
	public static final int INTELLECTUAL = 33;

	private int index=23;
	private Calendar birth = null;
	private Calendar theDay = null;

	private int daysFromBirth;                       //(2) 태어난지 몇일
	private int verticalCenter;
	private int verticalOffset;
	private int period=23;
	private int dayUnit;
	private int height;

	public BioRhythmGraph(Context context, int index) {
		super(context);
		this.index = index;
	}
	//(3) 생성할 때 주기, 생일, 오늘을 입력받는다.
	public BioRhythmGraph(Context context, int index, Calendar birth, Calendar theDay) {
		this(context, index);
		this.birth = birth;
		this.theDay = theDay;
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if( birth != null && theDay != null ) {
			canvas.drawColor(Color.WHITE);
			//canvas.drawColor(Color.BLACK);
			//(4) 축 그리기
			drawAxis(canvas);
			//(5) 바이오 리듬 그리기
			makeGraph(canvas);
			//(6) 바이오 리듬 종류- 텍스트로 표시
			drawText(canvas);
		}
	}
	//(6) ”신체지수: 56.7” 처럼 출력하기
	private void drawText(Canvas canvas) {
		Paint paint = new Paint();
		paint.setStyle(Paint.Style.STROKE);
		paint.setColor(getLineColor());
		paint.setTextSize(60);
		canvas.drawText(
				generateTextInformation( getBioRhythmValue(daysFromBirth)),
				0, 60, paint);    //(7) (0, 60) 좌표에 ”신체지수: 56.7” 처럼 문자열 만들기
	}
   //축 그리기
	private void drawAxis(Canvas canvas) {
		Paint paint = new Paint();
		Path path = new Path();
		paint.setStyle(Paint.Style.STROKE);
		paint.setColor(Color.GRAY);

		verticalOffset = 15;
		int margin = 50;
		height = getHeight() - margin;
		verticalCenter = height / 2;
		period = getWidth();
		dayUnit = period / 29;

		//center line
		path.moveTo(0, verticalCenter+verticalOffset);
		path.lineTo(period, verticalCenter+verticalOffset);
		canvas.drawPath(path, paint);
		//upper horizontal
		path.moveTo(0, verticalOffset);
		path.lineTo(period, verticalOffset);
		canvas.drawPath(path, paint);
		//under horizontal
		path.moveTo(0, height+verticalOffset);
		path.lineTo(period, height+verticalOffset);
		canvas.drawPath(path, paint);

		for(int i = 0, counter = 0; i <= period; i+=dayUnit, counter++) {
			path.moveTo(i, verticalOffset);
			path.lineTo(i, height+verticalOffset);
		}
		canvas.drawPath(path, paint);

		path = new Path();
		//paint.setColor(Color.YELLOW);
		paint.setColor(Color.RED);//오늘
		path.moveTo(dayUnit*15, verticalOffset);
		path.lineTo(dayUnit*15, height+verticalOffset);
		canvas.drawPath(path, paint);
	}
	public void makeGraph(Canvas canvas) {
		Path path = new Path();
		Paint paint = new Paint();
		paint.setStyle(Paint.Style.STROKE);
		paint.setColor(getLineColor());  //주기에 따른 색상
		daysFromBirth = daysFromBirth();   //(2) 태어난지 몇일
		int startDay = daysFromBirth - 15;  //앞뒤로 15일, 총 30일을 그래프에 그리기
		path.moveTo(0, -(float)getBioRhythmValue(startDay)+verticalCenter+verticalOffset);
		for(int i = dayUnit, j = startDay+1; i <= period ; i+=dayUnit, j++) {
			path.lineTo(i, -(float)getBioRhythmValue(j)+verticalCenter+verticalOffset);
		}
		canvas.drawPath(path, paint);
	}
	//(7) "신체지수: 56.7” 처럼 문자 만들기
	private String generateTextInformation(double value) {
		String result = "";
		switch( index ) {
			case PHYSICAL :
				result = "신체지수: ";
				break;
			case EMOTIONAL :
				result = "감정지수: ";
				break;
			case INTELLECTUAL :
				result = "지성지수: ";
				break;
		}
		return String.format("%s %.5f",result,(value*100.0/verticalCenter)) ; //.5f소수점 5자리
	}
	//바이오 리듬값 구하기 메서드에서 설명
	private double getBioRhythmValue(int days) {
		return verticalCenter* Math.sin( (days % index) * 2 * Math.PI / index );
	}
	//(2) 태어난지 몇일 , Calendar, 날짜변환에서 설명
	private int daysFromBirth() {
		long dateBirth=birth.getTimeInMillis();
		long dateToDay=theDay.getTimeInMillis();
		long days=dateToDay-dateBirth;
		return (int)(days/1000/24/60/60);
	}
    //바이오 리듬별 색상 구하기 switch에서
	private int getLineColor() {
		switch( index ) {
			case PHYSICAL :
				return Color.RED;
			case EMOTIONAL :
				return Color.GREEN;
			case INTELLECTUAL :
				return Color.BLUE;
			default :
				return Color.BLACK;
		}
	}
}
