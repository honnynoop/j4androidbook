package com.infopub.j4android.thermotrans;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class ThermoTransMainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText editCent;
    EditText editFha;
    RadioButton rtoFha;
    RadioButton rtoCent;
    Button convert;
    Button cancell;
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.activity_thermo_trans_main);
        editCent = (EditText)this.findViewById(R.id.editCent);
        editFha = (EditText)this.findViewById(R.id.editFha);
        rtoFha = (RadioButton)this.findViewById(R.id.rtoFha);
        rtoFha.setChecked(true);
        rtoCent = (RadioButton)this.findViewById(R.id.rtoCent);
        convert = (Button)this.findViewById(R.id.convert);
        cancell = (Button)this.findViewById(R.id.cancell);

        convert.setOnClickListener(this);
        cancell.setOnClickListener(this);
    }
    public void onClick(View v) {
        if (v==convert && rtoFha.isChecked()) {
            double val = Double.parseDouble(editCent.getText().toString());
            convertCentToFha(val);
        }else if ( v==convert && rtoCent.isChecked()) {
            double val = Double.parseDouble(editFha.getText().toString());
            convertFhaToCent(val);
        }else if ( v==cancell ) {
            editCent.setText("0.0");
            editFha.setText("0.0");
        }
    }
    protected String formats(double degree){
        return String.format("%1$.2f", degree);
    }
    public  double celsiusToFahrenheit(double c){
        return 9.0/5.0*c+32.0;
    }
    public  double fahrenheitToCelsius(double f){
        return 5.0/9.0*(f-32);
    }
    protected void convertCentToFha(double val) {
        editFha.setText(formats(celsiusToFahrenheit(val)));
    }
    protected void convertFhaToCent(double val) {
        editCent.setText(formats(fahrenheitToCelsius(val)));
    }
}