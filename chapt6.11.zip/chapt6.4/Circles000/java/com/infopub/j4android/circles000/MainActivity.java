package com.infopub.j4android.circles000;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        EarthquakeView circle=new EarthquakeView(this);  //this.getBaseContext()
        setContentView(circle);    //화면에 보여주기
        circle.setMagnitude(7);
    }
}
