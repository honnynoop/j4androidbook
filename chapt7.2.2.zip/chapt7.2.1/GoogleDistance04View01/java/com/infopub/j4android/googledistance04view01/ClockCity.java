package com.infopub.j4android.googledistance04view01;
import java.io.Serializable;

public class ClockCity implements Serializable {
    private double lat=37.5670;
    private double lng=126.9807;
    private String timezoneId="Asia/Seoul";
    private String countryName="Korea";

    public ClockCity(double lat, double lng, String timezoneId, String countryName) {
        this.lat = lat;
        this.lng = lng;
        this.timezoneId = timezoneId;
        this.countryName = countryName;
    }

    public ClockCity() {

    }

    @Override
    public String toString() {
        return "ClockCity{" +
                "lat=" + lat +
                ", lng=" + lng +
                ", timezoneId='" + timezoneId + '\'' +
                ", countryName='" + countryName + '\'' +
                '}';
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public String getTimezoneId() {
        return timezoneId;
    }

    public void setTimezoneId(String timezoneId) {
        this.timezoneId = timezoneId;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
}
