package com.infopub.j4android.googledistance04view01;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
//(1) ArrayAdapter를 상속한다.
public class CitiesAdapter extends ArrayAdapter<ClockCity> {
    //(2) 액티버티에 대한 정보를 갖는 컨텍스트 선언
    private  Context context;
    //(3) 리스트뷰에 보일 도시목록 선언
    private  ArrayList<ClockCity> clockCities =new ArrayList<ClockCity>();
    //(4) 컨텍스트와 시간목록을 대입받기 위한 생성자를 선언한다
    public CitiesAdapter(Context context, ArrayList<ClockCity> values) {
        super(context, android.R.layout.simple_list_item_1, values);  //(5) ArrayAdapter의 아이템즈의 레이아웃
        this.context = context;        //컨텍스트 대입
        this.clockCities = values;    //도시목록 대입
    }
    //(6) 각 아이템을 만들 getView()
    @SuppressLint("ViewHolder")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
//(7) 한 아이템의 레이아웃 -> 이렇게 하면 한 아이템의 레이아웃 찾는데!
        LayoutInflater inflater =
                (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.list_clock_item, parent, false);
        //(8) position에 있는 한 개의 도시정보
        ClockCity city= clockCities.get(position);   //getView(0) -> 도시목록.get(0)
//(9) Item 한개에 대한 화면 뷰(콤퍼넌트) 객체 생성
        TextView tvtimezone = (TextView) rowView.findViewById(R.id.tvtimezone);
        TextView tvtimes = (TextView) rowView.findViewById(R.id.tvtimes);
        TextView tvlocation = (TextView) rowView.findViewById(R.id.tvlocation);
        TextView tvlatlng = (TextView) rowView.findViewById(R.id.tvlatlng);
        ClockView clockview=(ClockView)rowView.findViewById(R.id.clockview);
        clockview.setTimezoneId(city.getTimezoneId());  //(10) 타입존 넣기 America/New_York
        String latlng = String.format("%f,%f", city.getLat(), city.getLng());
        //(11) 데이터를 화면에 붙이기
        tvtimezone.setText(city.getTimezoneId());
        tvtimes.setText(clockview.getTimes());
        tvlocation.setText(city.getCountryName() );
        tvlatlng.setText(latlng); return rowView;
    }
}
