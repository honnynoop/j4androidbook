package com.infopub.j4android.googledistance04view02;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CitiesAdapter extends ArrayAdapter<ClockCity> {

    private  Context context;
    private  ArrayList<ClockCity> clockCities =new ArrayList<ClockCity>();

    public CitiesAdapter(Context context, ArrayList<ClockCity> values) {
        super(context, android.R.layout.simple_list_item_1, values);
        this.context = context;
        this.clockCities = values;
    }
    @SuppressLint("ViewHolder")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.list_earth_item, parent, false);
        //한개의 도시정보
        ClockCity city= clockCities.get(position);
        //Item 한개에 대한 화면
        TextView tvtimezone = (TextView) rowView.findViewById(R.id.tvtimezone);
        TextView tvtimes = (TextView) rowView.findViewById(R.id.tvtimes);
        TextView tvlocation = (TextView) rowView.findViewById(R.id.tvlocation);
        TextView tvlatlng = (TextView) rowView.findViewById(R.id.tvlatlng);
        ClockView clockview=(ClockView)rowView.findViewById(R.id.clockview);
        clockview.setTimezoneId(city.getTimezoneId());  //타입존 넣기 America/New_York
        String latlng = String.format("%f,%f", city.getLat(), city.getLng());
        //데이터를 화면에 붙이기
        tvtimezone.setText(city.getTimezoneId());
        tvtimes.setText(clockview.getTimes());
        tvlocation.setText(city.getCountryName() );
        tvlatlng.setText(latlng);
        return rowView;
    }

}