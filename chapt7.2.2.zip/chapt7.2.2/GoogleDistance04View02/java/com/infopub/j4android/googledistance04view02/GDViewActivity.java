package com.infopub.j4android.googledistance04view02;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class GDViewActivity extends AppCompatActivity {
    private ArrayList<ClockCity> cities=new ArrayList<ClockCity>();
    private ListView listView ;
    private CitiesAdapter citiesAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gdview);
        //-----------개발자가 추가
        getCities();
        Toast.makeText(this, "Ready~~~~", Toast.LENGTH_LONG).show();
        showComponent();  //아답터를 이용하여 리스트뷰에 보이기
    }
    public void showComponent(){
        listView = (ListView) findViewById(R.id.listView);
        citiesAdapter = new CitiesAdapter(this, cities);
        listView.setAdapter(citiesAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //선택된 지진정보 -> 아이템
                ClockCity eq = (ClockCity) parent.getItemAtPosition(position);
                String latlng = String.format("%s, %s, [%f,%f]",
                        eq.getTimezoneId(), eq.getCountryName(), eq.getLat(), eq.getLng());
                Toast.makeText(getApplicationContext(), latlng, Toast.LENGTH_LONG).show();
            }
        });
        refreshView();    //핸들러 시작
    }
    public  void getCities() {
        //지진가방을 비운다.
        cities.clear();
        cities.add(new ClockCity(37.5670, 126.9807, "Asia/Seoul", "Korea"));
        cities.add(new ClockCity(47.01, 10.2,"Europe/Vienna","Austria"));
        cities.add(new ClockCity(40.714086, -74.228697,"America/New_York","US"));
        cities.add(new ClockCity(19.42847,-99.12766,"America/Mexico_City","Mexico"));
        cities.add(new ClockCity(39.9075,116.39723,"Asia/Shanghai","China"));
        cities.add(new ClockCity(55.75222,37.61556,"Europe/Moscow","Rusia"));
    }

    public void refreshView(){
        refreshViewHandler.sleep(1000 * 60);//1분
        cities=new ArrayList<ClockCity>();   //도시목록 저장 준비
        getCities();                          //도시 목록 가져오기
        citiesAdapter.clear();             //아답터 청소 - 아답터에 있던 도시목록 제거
        citiesAdapter.addAll(cities);     //새로운 도시 목록
    }

    private RefreshViewHandler refreshViewHandler = new RefreshViewHandler();

    class RefreshViewHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            refreshView();
        }
        public void sleep(long delayMillis) {
            this.removeMessages(0);
            sendMessageDelayed(obtainMessage(0), delayMillis);
        }
    };
}