package com.jungbo.j4android.earthquakeview01;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class EarthQuakeMainActivity extends AppCompatActivity {

    private ImageView earthimage;
    private TextView tvlatlng;
    private TextView tvtime;
    private TextView tvlocation;
    private TextView tvmagni;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_earth_quake_main);
        //-----------개발자가 추가
        showComponent();      //layout에서 설계한 것을 생성
        Toast.makeText(this, "이미지를 누르세요.", Toast.LENGTH_LONG).show();
    }
    private void showComponent() {
        //findViewById를 이용하여 레이아웃에서 설계한(선언한) 콤포넌트를 객체 생성
        earthimage=(ImageView)findViewById(R.id.earthimage);
        tvlatlng=(TextView)findViewById(R.id.tvlatlng);
        tvtime=(TextView)findViewById(R.id.tvtime);
        tvlocation=(TextView)findViewById(R.id.tvlocation);
        tvmagni=(TextView)findViewById(R.id.tvmagni);
        //이벤트 핸들러 객체 등록 -> 이미지를 누르면
        //이미지뷰가 눌리면 컨트롤인 액티버티가 감지
        //등록인 이벤트 핸들러 객체의 핸들러 메서드 호출
        earthimage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {   //이미지가 눌리면 실행, 핸들러 메서드 실행
                Toast.makeText(getApplicationContext(),
                        "이미지가 눌렸어요.", Toast.LENGTH_LONG).show();
            }
        });
        //earthimage.setOnClickListener(new EarthQuakeListener());
    }
    /*
    //이벤트 핸들러 객체
   public  class EarthQuakeListener implements View.OnClickListener{
       @Override
       public void onClick(View v) {   //이미지가 눌리면 실행, 핸들러 메서드 실행
           Toast.makeText(getApplicationContext(),
                   "이미지가 눌렸어요.", Toast.LENGTH_LONG).show();
       }
   }
   */
}
