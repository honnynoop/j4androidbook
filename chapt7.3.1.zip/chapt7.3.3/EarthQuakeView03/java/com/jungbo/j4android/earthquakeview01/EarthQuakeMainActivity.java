package com.jungbo.j4android.earthquakeview01;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class EarthQuakeMainActivity extends AppCompatActivity {

    private ArrayList<KREarthQuake> kREarthQuakes=new ArrayList<KREarthQuake>();
    private ListView listView ;
    private EarthquakeAdapter earthquakeAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_earth_quake_main);
        //-----------개발자가 추가
        getEarthQuakes(); // 데이터 가져오기, 성공하면 isConnection=true
        Toast.makeText(this, "Ready~~~~", Toast.LENGTH_LONG).show();
        showComponent();
    }
    public void showComponent(){
        listView = (ListView) findViewById(R.id.listView);
        earthquakeAdapter = new EarthquakeAdapter(this, kREarthQuakes);
        listView.setAdapter(earthquakeAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //선택된 지진정보 -> 아이템
                KREarthQuake eq = (KREarthQuake) parent.getItemAtPosition(position);
                String latlng = String.format("%s, %s, %f",
                        eq.getLocation() ,eq.getTime(),eq.getMagnitude());
                Toast.makeText(getApplicationContext(), latlng, Toast.LENGTH_LONG).show();
            }
        });
    }
    public  void getEarthQuakes() {
        //지진가방을 비운다.
        kREarthQuakes.clear();
        //지진 필통에 지진정보를 넣고, 지진가방에 지진필통을 저장한다.
        kREarthQuakes.add(new KREarthQuake(27.400000,128.600000,"2016-09-26 14:20:00","일본 오키나와현 오키나와 북동쪽 161km 해역",5.700000));
        kREarthQuakes.add(new KREarthQuake(41.700000,143.000000,"2016-09-26 14:13:00","일본 홋카이도 구시로 남서쪽 182km 해역",5.500000));
        kREarthQuakes.add(new KREarthQuake(34.400000,141.700000,"2016-09-23 09:14:00","일본 혼슈 지바현 지바 남동쪽 198km 해역",6.500000));
        kREarthQuakes.add(new KREarthQuake(30.500000,142.300000,"2016-09-21 01:22:00","일본 혼슈 가나가와현 요코하마 남남동쪽 603km 해역",6.300000));
        kREarthQuakes.add(new KREarthQuake(-5.580000,-76.970000,"2016-09-10 19:08:19","페루 모요밤바 북쪽 51km 지역",6.000000));
        kREarthQuakes.add(new KREarthQuake(-37.500000,178.800000,"2016-09-02 01:37:57","뉴질랜드 오포티키 동북동쪽 145km 해역",7.200000));
        kREarthQuakes.add(new KREarthQuake(0.100000,-17.800000,"2016-08-29 13:30:00","라이베리아 몬로비아 남서쪽 1037km 해역",7.400000));
        kREarthQuakes.add(new KREarthQuake(30.500000,138.300000,"2016-08-26 02:05:00","일본 혼슈 시즈오카현 시즈오카 남쪽 498km 해역",6.100000));
        kREarthQuakes.add(new KREarthQuake(20.920000,94.580000,"2016-08-24 19:34:55","미얀마 네피도 북동쪽 205km 지역",6.800000));
        kREarthQuakes.add(new KREarthQuake(42.710000,13.170000,"2016-08-24 10:36:33","이탈리아 노르챠 남동쪽 10km 지역",6.200000));
        kREarthQuakes.add(new KREarthQuake(29.900000,139.500000,"2016-08-22 18:38:00","일본 혼슈 시즈오카현 시즈오카 남쪽 574km 해역",5.700000));
        kREarthQuakes.add(new KREarthQuake(40.300000,143.700000,"2016-08-21 00:58:00","일본 혼슈 이와테현 모리오카 동북동쪽 227km 해역",5.900000));
        kREarthQuakes.add(new KREarthQuake(40.300000,143.900000,"2016-08-20 18:01:00","일본 혼슈 이와테현 모리오카 동북동쪽 243km 해역",6.000000));
        kREarthQuakes.add(new KREarthQuake(-55.340000,-31.940000,"2016-08-19 16:32:22","사우스조지아 사우스샌드위치 제도 남동쪽 320km 해역",7.400000));
        kREarthQuakes.add(new KREarthQuake(37.400000,141.700000,"2016-08-15 16:04:00","일본 혼슈 후쿠시마현 후쿠시마 동남동쪽 115km 해역",5.500000));
        kREarthQuakes.add(new KREarthQuake(-22.700000,173.200000,"2016-08-12 10:26:38","남태평양 피지 수바 남서쪽 740km 해역",7.600000));
        kREarthQuakes.add(new KREarthQuake(25.200000,141.900000,"2016-08-05 01:25:00","일본 혼슈 시즈오카현 시즈오카 남남동쪽 1138km 해역",6.300000));
        kREarthQuakes.add(new KREarthQuake(-22.390000,-65.990000,"2016-08-04 23:15:11","아르헨티나 아브라팜파 북서쪽 48km 지역",6.000000));
        kREarthQuakes.add(new KREarthQuake(18.500000,145.800000,"2016-07-30 06:18:24","태평양 괌 북북동쪽 566km 해역",7.700000));
        kREarthQuakes.add(new KREarthQuake(36.400000,140.600000,"2016-07-27 23:47:00","일본 혼슈 이바라키현 미토 동북동쪽 12km 지역",5.300000));
        kREarthQuakes.add(new KREarthQuake(-26.110000,-70.650000,"2016-07-26 02:26:49","칠레 디에고 데 알마그로 서북서쪽 66km 지역",6.200000));
        kREarthQuakes.add(new KREarthQuake(36.100000,140.000000,"2016-07-20 07:25:00","일본 사이타마현 사이타마 북동쪽 42km 지역",5.000000));
        kREarthQuakes.add(new KREarthQuake(36.010000,139.900000,"2016-07-17 13:24:00","일본 혼슈 사이타마현 사이타마 북동쪽 28km 지역",5.000000));
        kREarthQuakes.add(new KREarthQuake(37.000000,142.400000,"2016-06-27 07:57:00","일본 혼슈 이바라키현 미토 동북동쪽 186km 해역",5.800000));
        kREarthQuakes.add(new KREarthQuake(39.490000,73.330000,"2016-06-26 20:17:12","키르기스스탄 잘랄아바트 남쪽 160km 지역",6.300000));
        kREarthQuakes.add(new KREarthQuake(23.500000,123.300000,"2016-06-24 06:05:30","대만 타이베이 남동쪽 249km 해역",6.000000));
        kREarthQuakes.add(new KREarthQuake(36.000000,139.900000,"2016-06-12 07:54:00","일본 혼슈 사이타마현 사이타마 북동쪽 28km 지역",5.000000));
        kREarthQuakes.add(new KREarthQuake(12.840000,-87.010000,"2016-06-10 12:25:22","니카라과 마나과 북서쪽 114km 지역",6.100000));
        kREarthQuakes.add(new KREarthQuake(25.380000,122.420000,"2016-05-31 14:23:46","대만 타이베이 동북동쪽 103km 해역",7.200000));
        kREarthQuakes.add(new KREarthQuake(-56.260000,-27.040000,"2016-05-28 18:47:01","사우스조지아 사우스샌드위치 제도 비소코이 섬 북북동쪽 50km 해역",7.300000));
        kREarthQuakes.add(new KREarthQuake(26.900000,130.300000,"2016-05-27 12:44:00","일본 오키나와현 오키나와 동북동쪽 272km 해역",5.500000));
        kREarthQuakes.add(new KREarthQuake(22.920000,120.620000,"2016-05-22 05:51:42","대만 카오슝 북동쪽 53km 지역",5.200000));
        kREarthQuakes.add(new KREarthQuake(0.470000,-79.640000,"2016-05-19 01:46:44","에콰도르 로사 사라테 북서쪽 24km 지역",6.800000));
        kREarthQuakes.add(new KREarthQuake(0.420000,-79.760000,"2016-05-18 16:57:04","에콰도르 로사 사라테 서북서쪽 34km 지역",6.700000));
        kREarthQuakes.add(new KREarthQuake(36.000000,139.900000,"2016-05-16 21:23:00","일본 도쿄 북동쪽 39km 지역",5.600000));
        kREarthQuakes.add(new KREarthQuake(24.680000,122.000000,"2016-05-12 13:29:55","대만 타이베이 남동쪽 63km 해역",5.500000));
        kREarthQuakes.add(new KREarthQuake(24.690000,121.950000,"2016-05-12 12:17:14","대만 타이베이 남동쪽 58km 해역",5.800000));
        kREarthQuakes.add(new KREarthQuake(43.500000,147.500000,"2016-05-03 09:01:00","일본 홋카이도 구시로 동북동쪽 259km 해역",5.700000));
        kREarthQuakes.add(new KREarthQuake(-16.200000,167.700000,"2016-04-29 04:33:25","바누아투 라카토로 동남동쪽 31km 해역",7.300000));
        kREarthQuakes.add(new KREarthQuake(23.260000,121.300000,"2016-04-28 03:19:06","대만 카오슝 북동쪽 131km 지역",5.500000));
        kREarthQuakes.add(new KREarthQuake(37.800000,141.700000,"2016-04-20 21:19:00","일본 혼슈 미야기현 센다이 남동쪽 89km 해역",5.600000));
        kREarthQuakes.add(new KREarthQuake(32.600000,130.700000,"2016-04-19 17:52:00","일본 규슈 구마모토현 구마모토 남쪽 23km 지역",5.500000));
        kREarthQuakes.add(new KREarthQuake(33.000000,131.200000,"2016-04-18 20:42:00","일본 규슈 오이타현 오이타 남서쪽 46km 지역",5.800000));
        kREarthQuakes.add(new KREarthQuake(0.200000,-80.100000,"2016-04-17 08:58:38","에콰도르 페데르날레스 북북서쪽 14km 해역",7.400000));
        kREarthQuakes.add(new KREarthQuake(33.300000,131.400000,"2016-04-16 07:11:00","일본 규슈 오이타현 오이타 서북서쪽 21km 지역",5.300000));
        kREarthQuakes.add(new KREarthQuake(33.000000,131.200000,"2016-04-16 03:55:00","일본 규슈 오이타현 오이타 남서쪽 46km 지역",5.800000));
        kREarthQuakes.add(new KREarthQuake(33.000000,131.100000,"2016-04-16 03:03:00","일본 규슈 구마모토현 구마모토 동북동쪽 43km 지역",5.800000));
        kREarthQuakes.add(new KREarthQuake(32.900000,130.900000,"2016-04-16 01:46:00","일본 규슈 구마모토현 구마모토 동북동쪽 21km 지역",6.000000));
        kREarthQuakes.add(new KREarthQuake(32.800000,130.800000,"2016-04-16 01:25:00","일본 규슈 구마모토현 구마모토 동쪽 9km 지역",7.300000));
        kREarthQuakes.add(new KREarthQuake(32.700000,130.800000,"2016-04-15 00:03:00","일본 규슈 구마모토현 구마모토 남동쪽 14km 지역",6.400000));
        kREarthQuakes.add(new KREarthQuake(32.800000,130.800000,"2016-04-14 22:07:00","일본 규슈 구마모토현 구마모토 동쪽 9km 지역",5.700000));
        kREarthQuakes.add(new KREarthQuake(32.700000,130.800000,"2016-04-14 21:26:00","일본 규슈 구마모토현 구마모토 남동쪽 14km 지역",6.400000));
        kREarthQuakes.add(new KREarthQuake(23.130000,94.900000,"2016-04-13 22:55:17","미얀마 네피도 북북서쪽 396km 지역",6.900000));
        kREarthQuakes.add(new KREarthQuake(36.490000,71.160000,"2016-04-10 19:28:58","아프카니스탄 카불 북동쪽 282km 지역",6.600000));
        kREarthQuakes.add(new KREarthQuake(-14.190000,166.910000,"2016-04-03 17:23:49","바누아투 포트빌라 북북서쪽 420km 해역",7.200000));
        kREarthQuakes.add(new KREarthQuake(57.050000,-157.850000,"2016-04-02 14:50:04","알래스카 앵커리지 남서쪽 649km 지역",6.400000));
        kREarthQuakes.add(new KREarthQuake(33.400000,136.400000,"2016-04-01 11:39:00","일본 혼슈 와카야마현 와카야마 남동쪽 146km 해역",6.100000));
        kREarthQuakes.add(new KREarthQuake(-4.900000,94.230000,"2016-03-02 21:49:46","인도네시아 무아라 시베루트 남서쪽 662km 해역",7.900000));
        kREarthQuakes.add(new KREarthQuake(24.400000,143.100000,"2016-02-22 06:27:00","일본 혼슈 시즈오카현 시즈오카 남남동쪽 1261km 해역",6.400000));
        kREarthQuakes.add(new KREarthQuake(23.000000,120.900000,"2016-02-18 10:09:39","대만 카오슝 동북동쪽 81km 지역",5.100000));
        kREarthQuakes.add(new KREarthQuake(30.400000,139.300000,"2016-02-15 03:10:00","일본 혼슈 시즈오카현 시즈오카 남쪽 516km 해역",6.200000));
        kREarthQuakes.add(new KREarthQuake(-9.590000,119.400000,"2016-02-12 19:02:24","인도네시아 와잉아푸 서쪽 94km 지역",6.500000));
        kREarthQuakes.add(new KREarthQuake(-30.630000,-71.620000,"2016-02-10 09:33:05","칠레 라세네나 남남서쪽 87km 지역",6.300000));
        kREarthQuakes.add(new KREarthQuake(22.900000,120.500000,"2016-02-06 04:57:30","대만 타이난 동남동쪽 31km 지역",6.700000));
        kREarthQuakes.add(new KREarthQuake(25.210000,123.580000,"2016-02-02 23:19:22","대만 타이베이 동쪽 212km 해역",6.800000));
        kREarthQuakes.add(new KREarthQuake(39.700000,142.900000,"2016-02-02 14:32:00","일본 혼슈 이와테현 모리오카 동쪽 149km 해역",5.700000));
        kREarthQuakes.add(new KREarthQuake(54.000000,158.700000,"2016-01-30 12:25:00","러시아 캄차카반도 옐리조보 북북동쪽 92km 지역",7.000000));
        kREarthQuakes.add(new KREarthQuake(59.660000,-153.450000,"2016-01-24 19:30:30","미국 알래스카 앵커리지 남서쪽 261km 해역",7.100000));
        kREarthQuakes.add(new KREarthQuake(37.680000,101.620000,"2016-01-21 02:13:00","중국 칭하이성 하이둥시 북쪽 138km 지역",6.400000));
        kREarthQuakes.add(new KREarthQuake(-19.810000,-63.330000,"2016-01-14 12:25:27","볼리비아 라파스 남동쪽 627km 지역",6.000000));
        kREarthQuakes.add(new KREarthQuake(42.000000,142.800000,"2016-01-14 12:25:00","일본 홋카이도 삿포로 남동쪽 167km 해역",6.700000));
        kREarthQuakes.add(new KREarthQuake(44.500000,141.300000,"2016-01-12 02:14:00","일본 홋카이도 삿포로 북쪽 160km 해역",6.000000));
        kREarthQuakes.add(new KREarthQuake(28.100000,129.500000,"2016-01-09 23:12:00","일본 오키나와현 오키나와 북동쪽 277km 해역",5.500000));
        kREarthQuakes.add(new KREarthQuake(22.100000,143.800000,"2016-01-06 07:01:00","일본 혼슈 시즈오카현 시즈오카 남남동쪽 1526km 해역",6.000000));
        kREarthQuakes.add(new KREarthQuake(24.880000,93.630000,"2016-01-04 08:05:20","인도 임팔 서북서쪽 33km 지역",6.800000));
        kREarthQuakes.add(new KREarthQuake(44.810000,129.950000,"2016-01-02 13:22:00","중국 헤이룽장성 무단장시 북동쪽 38km 지역",6.400000));
    }
}
