package com.jungbo.j4android.earthquakeview01;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.AsyncTask;
import android.util.Log;

import java.util.ArrayList;

public class EarthQuakeRequestAsync
		extends AsyncTask<String, Void, ArrayList<KREarthQuake>> {

	Activity activity;
	ArrayList<KREarthQuake> krEarthQuakes =new ArrayList<KREarthQuake>();
	ProgressDialog progressDialog;
	boolean isConnection=false;

	//RequestFrom rfw;   //해외
	RequestFrom rfw;  //내부

	public EarthQuakeRequestAsync(Activity ac){
		activity = ac;
	}
	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		//rfw=new RequestFromKMA();  //해외
		rfw=new RequestFromKMAKo();  //국내
		progressDialog = ProgressDialog.show(activity, "Reading", "Reading Earthquake datas!");
	}
	@Override
	protected ArrayList<KREarthQuake> doInBackground(String...params) {
		getEarthQuakes(params);
		return krEarthQuakes;
	}
	public String para(String key, String value){
		return String.format("%s=%s", key, value);
	}

	public void getEarthQuakes(String...params){
		krEarthQuakes.clear();
		//String [] datas=new String [] { "2011-01-01","2016-09-30","2" };
		String urls="http://web.kma.go.kr/weather/earthquake_volcano/domesticlist.jsp";
		//String urls="http://www.kma.go.kr/weather/earthquake_volcano/internationallist.jsp";
		String startTm=params[0];
		String endTm=params[1];
		String startSize=params[2];
		int endSize=999;
		String a= String.format("%s?%s&%s&%s",
				urls,
				para("startTm", startTm),
				para("endTm", endTm),
				para("startSize", startSize + "")
		);
		Log.i("doInBackground", "------------------------------" + a);
		rfw.getAllHtml(a);   //웹에서 얻은 모든 문자열을 저장
		isConnection=rfw.isConnection();  //문자열을 정상적으로 읽었나
		String str="<table class=\"table_develop";
		rfw.getEarthQuakes(str);
		krEarthQuakes =rfw.getKREarthQuakes();
	}

	@Override
	protected void onPostExecute(ArrayList<KREarthQuake> result) {
		super.onPostExecute(result);
		if(isConnection) {
			if(activity instanceof EarthQuakeMainActivity) {
				((EarthQuakeMainActivity) activity).updateResult(result);
			}
			progressDialog.dismiss();
		} else {
			progressDialog.dismiss();
			AlertDialog.Builder adBuilder = new AlertDialog.Builder(activity);

			adBuilder.setMessage("Check Http Earthquake Connection and try again.")
					.setTitle("No Internet Access")
					.setPositiveButton("OK", new OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							return;
						}
					}).create();

			adBuilder.show();
		}
	}

}
