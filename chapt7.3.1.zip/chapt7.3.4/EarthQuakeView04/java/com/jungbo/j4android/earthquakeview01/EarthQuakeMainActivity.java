package com.jungbo.j4android.earthquakeview01;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class EarthQuakeMainActivity extends AppCompatActivity {

    private ArrayList<KREarthQuake> kREarthQuakes=new ArrayList<KREarthQuake>();
    private ListView listView ;
    private EarthquakeAdapter earthquakeAdapter;

    private  EarthQuakeRequestAsync async;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_earth_quake_main);
        //-----------개발자가 추가
        Toast.makeText(this, "Ready~~~~", Toast.LENGTH_LONG).show();
        showComponent();
        //가져온 지진목록 보여주기는 비동기로 이동 updateResult() 호출
    }
    public void showComponent(){
        listView = (ListView) findViewById(R.id.listView);
        earthquakeAdapter = new EarthquakeAdapter(this, kREarthQuakes);
        listView.setAdapter(earthquakeAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //선택된 지진정보 -> 아이템
                KREarthQuake eq = (KREarthQuake) parent.getItemAtPosition(position);
                String latlng = String.format("%s, %s, %f",
                        eq.getLocation(), eq.getTime(), eq.getMagnitude());
                Toast.makeText(getApplicationContext(), latlng, Toast.LENGTH_LONG).show();
            }
        });
        async =new EarthQuakeRequestAsync(this);
        String [] datas=new String [] { "2010-01-01",todate2(new Date()),"3" ,"999"};
        async.execute(datas);  //AsyncTask doInBackgraound(datas) 호출
    }
    public void updateResult(final ArrayList<KREarthQuake> result) {
        this.kREarthQuakes=result;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                earthquakeAdapter.clear();
                earthquakeAdapter.addAll(kREarthQuakes);
                //earthquakeAdapter = new EarthquakeAdapter(this, kREarthQuakes);
                //listView.setAdapter(earthquakeAdapter);
            }
        });
    }
    //년도-월-일 2016-09-28
    public  String todate2(Date dd){
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(dd);
    }
}
