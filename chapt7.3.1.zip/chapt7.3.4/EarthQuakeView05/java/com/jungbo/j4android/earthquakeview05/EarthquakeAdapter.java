package com.jungbo.j4android.earthquakeview05;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class EarthquakeAdapter extends ArrayAdapter<KREarthQuake> {

    private final Context context;
    private final ArrayList<KREarthQuake> earthQuakes;

    public EarthquakeAdapter(Context context, ArrayList<KREarthQuake> values) {
        super(context, android.R.layout.simple_list_item_1, values);
        this.context = context;
        this.earthQuakes = values;
    }
    @SuppressLint("ViewHolder")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.list_earth_item, parent, false);
        //한개의 지진정보
        KREarthQuake earth=earthQuakes.get(position);
        //Item 한개에 대한 화면
        TextView tvlatlng = (TextView) rowView.findViewById(R.id.tvlatlng);
        TextView tvtime = (TextView) rowView.findViewById(R.id.tvtime);
        TextView tvlocation = (TextView) rowView.findViewById(R.id.tvlocation);
        TextView tvmag = (TextView) rowView.findViewById(R.id.tvmagni);
        //ImageView view1=(ImageView)rowView.findViewById(R.id.earthimage);
        EarthquakeView view1=(EarthquakeView)rowView.findViewById(R.id.earthimage);
        view1.setMagnitude(earth.getMagnitude());  //지진세기를 원으로 표현
        String latlng = String.format("%f,%f", earth.getLatitude(), earth.getLongitude());
        //데이터를 화면에 붙이기
        //view1.setImageResource(imageResource(earth.getMagnitude()));
        tvlatlng.setText(latlng);
        tvtime.setText(earth.getTime());
        tvlocation.setText(earth.getLocation());
        tvmag.setText(earth.getMagnitude()+"");
        return rowView;
    }
    //지진 세기별 이미지 고유번호
    public  int imageResource(double magnitude) {
        if (magnitude >= 8.0) {
            return R.drawable.e509;
        } else if (magnitude >= 7.0) {
            return R.drawable.e507;
        } else if (magnitude >= 6.0) {
            return R.drawable.e505;
        } else {
            return R.drawable.e503;
        }
    }
}