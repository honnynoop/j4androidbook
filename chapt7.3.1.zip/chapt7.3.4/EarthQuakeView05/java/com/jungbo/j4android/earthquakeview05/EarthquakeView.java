package com.jungbo.j4android.earthquakeview05;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class EarthquakeView extends View {
	double magnitude=2.0;
   //new로 생성할 때
	public EarthquakeView(Context context) {
		super(context);
	}
	//findById로 생성할 때
	public EarthquakeView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public void setMagnitude(double magnitude) {
		this.magnitude = magnitude;
		invalidate();   //자동으로 onDraw 호출
	}

	public void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		setBackgroundColor(Color.WHITE);
		Paint circleOut = new Paint(Paint.ANTI_ALIAS_FLAG);
		if (magnitude >= 8.0) {
			circleOut.setColor(Color.RED);
			canvas.drawCircle(getWidth() / 2, getHeight() / 2, (float) (magnitude * 11), circleOut);
		} else if (magnitude >= 7.0) {
			circleOut.setColor(Color.BLUE);
			canvas.drawCircle(getWidth() / 2, getHeight() / 2, (float) (magnitude * 8), circleOut);
		} else if (magnitude >= 6.0) {
			circleOut.setColor(Color.BLACK);
			canvas.drawCircle(getWidth() / 2, getHeight() / 2, (float) (magnitude * 5), circleOut);
		} else {
			circleOut.setColor(Color.GREEN);
			canvas.drawCircle(getWidth() / 2, getHeight() / 2, (float) (magnitude * 2), circleOut);
		}
	}

	public void showCircle(Canvas canvas, float width, float height,
						   float magnitude, Paint paint, int color){
		paint.setColor(color);
		canvas.drawCircle(width, height, magnitude, paint);
	}
}
