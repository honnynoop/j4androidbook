package com.jungbo.j4android.earthquakeview01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class EarthQuakeMainActivity extends AppCompatActivity implements View.OnClickListener{

    private ImageView earthimage;
    private TextView tvlatlng;
    private TextView tvtime;
    private TextView tvlocation;
    private TextView tvmagni;

    //지진목록 -> 지진가방, KREarthQuake 한 지진의 정보->  필통
    private ArrayList<KREarthQuake> kREarthQuakes=new ArrayList<KREarthQuake>();
    private  int index=0;    //지진목록에서 지진 정보 위치

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_earth_quake_main);
        //-----------개발자가 추가
        getEarthQuakes(); //지진정보 준비
        Toast.makeText(this, "이미지를 누르면 지진정보가 보여요", Toast.LENGTH_LONG).show();
        showComponent();      //layout에서 설계한 것을 생성
    }
    private void showComponent() {
        //findViewById를 이용하여 레이아웃에서 설계한(선언한) 콤포넌트를 객체 생성
        earthimage=(ImageView)findViewById(R.id.earthimage);
        tvlatlng=(TextView)findViewById(R.id.tvlatlng);
        tvtime=(TextView)findViewById(R.id.tvtime);
        tvlocation=(TextView)findViewById(R.id.tvlocation);
        tvmagni=(TextView)findViewById(R.id.tvmagni);
        //이벤트 등록 -> 이미지를 누르면
        earthimage.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {   //이미지가 눌리면 실행
        if(index>=kREarthQuakes.size()){  //사진의 개수를 넘으면 다시 0으로 설정
            index=0;
        }
        //지진목록에서 한 지진 가져오기
        KREarthQuake earth=kREarthQuakes.get(index++);  //이미지를 누르면 index 1증가
        //지진정보 보이기
        showEach(earth);
    }
    private void showEach(KREarthQuake earth){
        String latlng = String.format("%f,%f", earth.getLatitude(), earth.getLongitude());
        //데이터를 화면에 붙이기
       //찾은 국기를 이미지뷰에 보이기
        earthimage.setImageResource(imageResource(earth.getLocation()));
        tvlatlng.setText(latlng);      //위도경도
        tvtime.setText(earth.getTime()); //발생시간
        tvlocation.setText(earth.getLocation());//발생위치
        tvmagni.setText(earth.getMagnitude()+""); //세기
    }
    //발생장소에서 나라 국기 찾기
    public  int imageResource(String msg){
        if(msg.contains("일본")){ return R.drawable.jp;
        }else  if(msg.contains("페루")){ return R.drawable.pe;
        }else  if(msg.contains("뉴질랜드")){ return R.drawable.nz;
        }else  if(msg.contains("칠레")){ return R.drawable.cl;
        }else  if(msg.contains("대만")){ return R.drawable.tw;
        }else  if(msg.contains("러시아")){ return R.drawable.ru;
        }else  if(msg.contains("미국")){ return R.drawable.us;
        }else  if(msg.contains("인도")){ return R.drawable.in;
        }else  if(msg.contains("중국")){ return R.drawable.cn;
        }else return R.drawable.kr;
    }
    public  void getEarthQuakes() {
        //지진가방을 비운다.
        kREarthQuakes.clear();
        //지진 필통에 지진정보를 넣고, 지진가방에 지진필통을 저장한다.
        kREarthQuakes.add(new KREarthQuake(27.400000,128.600000,"2016-09-26 14:20:00","일본 오키나와현 오키나와 북동쪽 161km 해역",5.700000));
        kREarthQuakes.add(new KREarthQuake(41.700000,143.000000,"2016-09-26 14:13:00","일본 홋카이도 구시로 남서쪽 182km 해역",5.500000));
        kREarthQuakes.add(new KREarthQuake(34.400000,141.700000,"2016-09-23 09:14:00","일본 혼슈 지바현 지바 남동쪽 198km 해역",6.500000));
        kREarthQuakes.add(new KREarthQuake(30.500000,142.300000,"2016-09-21 01:22:00","일본 혼슈 가나가와현 요코하마 남남동쪽 603km 해역",6.300000));
        kREarthQuakes.add(new KREarthQuake(-5.580000,-76.970000,"2016-09-10 19:08:19","페루 모요밤바 북쪽 51km 지역",6.000000));
        kREarthQuakes.add(new KREarthQuake(-37.500000,178.800000,"2016-09-02 01:37:57","뉴질랜드 오포티키 동북동쪽 145km 해역",7.200000));
        kREarthQuakes.add(new KREarthQuake(-30.630000,-71.620000,"2016-02-10 09:33:05","칠레 라세네나 남남서쪽 87km 지역",6.300000));
        kREarthQuakes.add(new KREarthQuake(22.900000,120.500000,"2016-02-06 04:57:30","대만 타이난 동남동쪽 31km 지역",6.700000));
        kREarthQuakes.add(new KREarthQuake(25.210000,123.580000,"2016-02-02 23:19:22","대만 타이베이 동쪽 212km 해역",6.800000));
        kREarthQuakes.add(new KREarthQuake(39.700000,142.900000,"2016-02-02 14:32:00","일본 혼슈 이와테현 모리오카 동쪽 149km 해역",5.700000));
        kREarthQuakes.add(new KREarthQuake(54.000000,158.700000,"2016-01-30 12:25:00","러시아 캄차카반도 옐리조보 북북동쪽 92km 지역",7.000000));
        kREarthQuakes.add(new KREarthQuake(59.660000,-153.450000,"2016-01-24 19:30:30","미국 알래스카 앵커리지 남서쪽 261km 해역",7.100000));
        kREarthQuakes.add(new KREarthQuake(24.880000,93.630000,"2016-01-04 08:05:20","인도 임팔 서북서쪽 33km 지역",6.800000));
        kREarthQuakes.add(new KREarthQuake(44.810000,129.950000,"2016-01-02 13:22:00","중국 헤이룽장성 무단장시 북동쪽 38km 지역",6.400000));
    }
}
