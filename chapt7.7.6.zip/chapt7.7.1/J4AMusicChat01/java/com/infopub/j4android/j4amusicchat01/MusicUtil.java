package com.infopub.j4android.j4amusicchat01;

/**
 * Created by honeyjava on 2016-08-12.
 */
public class MusicUtil {
    //자신의 APIKEY로 변경하세요.
    public static String APIKEY="cf887f978dccc5a68c06bb35b1b78319";
    public static String FM="http://ws.audioscrobbler.com/2.0/";
    public static String FORMAT="&format=json";
    public static String METHOD1="?method=tag.gettoptracks";
    public static int LINE=50;
    public static String LIMIT="&limit="+LINE;
    public static String TAG="&tag=";
    public static String TOPTRACK=FM+METHOD1+FORMAT+LIMIT+"&api_key="+APIKEY+TAG;
}
