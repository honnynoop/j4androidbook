package com.infopub.j4android.j4amusicchat01;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ArtistSearchActivity extends AppCompatActivity {
    
    ListView listView;
    TrackListAdapter lAdapter;
    ArrayList<Track> tracks=new ArrayList<Track>();
    private ImageButton tracksButton;           //이미지버튼
    private ImageListRequest ira;                //이미지 저장
    private EditText musickindsSpinner;
    private InputMethodManager inputMethodManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artist_search);
        setTitle("Top Artist Search");
        this.inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        this.musickindsSpinner = (EditText) this.findViewById(R.id.musickinds);
        this.tracksButton = (ImageButton)this.findViewById(R.id.track_button);

        ira=new ImageListRequest();
        listView = (ListView) findViewById(R.id.listView2);
        lAdapter=new TrackListAdapter(this,tracks,ira);
        listView.setAdapter(lAdapter);



        this.tracksButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                inputMethodManager.hideSoftInputFromWindow(tracksButton.getWindowToken(), 0);
                ArtistRequestAsync lfmTask = new ArtistRequestAsync(ArtistSearchActivity.this);
                try {
                    //음악가 입력
                    String artistTxt = musickindsSpinner.getText().toString();
                    lfmTask.execute(artistTxt);
                } catch (Exception e) {
                    lfmTask.cancel(true);
                }

            }
        });
        musickindsSpinner.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                musickindsSpinner.setText("");
                return false;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Track eq = (Track) parent.getItemAtPosition(position);
                String sf=String.format("artist:%s \n track:%s",eq.getArtisturl(),eq.getTrackurl());
                alert(sf);
            }

        });

    }

    public void alert (String msg)
    {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
    }
    public void updateTracks(ArrayList<Track> result){
        lAdapter.clear();
        lAdapter.addAll(result);

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                listView.setAdapter(lAdapter);
                lAdapter.notifyDataSetChanged();
            }
        });
    }
    @Override
    protected void onDestroy() {
        listView.setAdapter(null);
        super.onDestroy();
    }
}

