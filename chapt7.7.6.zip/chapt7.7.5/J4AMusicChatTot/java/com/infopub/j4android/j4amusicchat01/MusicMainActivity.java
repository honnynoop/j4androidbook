package com.infopub.j4android.j4amusicchat01;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;

public class MusicMainActivity extends AppCompatActivity {

    ImageButton trackListBtn ;
    ImageButton trackGridBtn ;
    ImageButton  artisSBtn;
    ImageButton  billboardBtn;
    ImageButton  billBoard200Btn;
    ImageButton  billBoardArtistBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_main);
        setTitle("J4AMusic");
        trackListBtn=(ImageButton) this.findViewById(R.id.trackListBtn);
        trackGridBtn=(ImageButton) this.findViewById(R.id.trackGridBtn);
        artisSBtn=(ImageButton) this.findViewById(R.id.artisSBtn);
        billboardBtn=(ImageButton) this.findViewById(R.id.billBoardBtn);
        billBoard200Btn=(ImageButton) this.findViewById(R.id.billBoard200Btn);
        billBoardArtistBtn=(ImageButton) this.findViewById(R.id.billBoardArtistBtn);

        trackListBtn.setOnClickListener(new MusicListener() );
        trackGridBtn.setOnClickListener(new MusicListener() );
        artisSBtn.setOnClickListener(new MusicListener() );
        billboardBtn.setOnClickListener(new MusicListener() );
        billBoard200Btn.setOnClickListener(new MusicListener() );
        billBoardArtistBtn.setOnClickListener(new MusicListener() );
    }
    //Nested Class- EHO
    class  MusicListener implements  View.OnClickListener{
        Intent intent;
        public void onClick(View v) {
            if(v.getId()==R.id.trackListBtn){
                 intent = new Intent(MusicMainActivity.this,
                        TopTrackListActivity.class);
            }else  if(v.getId()==R.id.trackGridBtn){
                intent = new Intent(MusicMainActivity.this,
                        TopTrackGridActivity.class);
            }else  if(v.getId()==R.id.artisSBtn){
                intent = new Intent(MusicMainActivity.this,
                        ArtistSearchActivity.class);
            }else  if(v.getId()==R.id.billBoardBtn){
                intent = new Intent(MusicMainActivity.this,
                        BillboardActivity.class);
            } else  if(v.getId()==R.id.billBoard200Btn){
                intent = new Intent(MusicMainActivity.this,
                        Billboard200Activity.class);
            } else  if(v.getId()==R.id.billBoardArtistBtn){
                intent = new Intent(MusicMainActivity.this,
                        BillboardArtistActivity.class);
            }
            startActivity(intent);
        }
    }
}
