package com.jungbo.j4android.musicchartapps2;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;


public class FullscreenActivity extends AppCompatActivity {


    private GridView mContentView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //requestWindowFeature(Window.FEATURE_NO_TITLE);//must
        setContentView(R.layout.activity_fullscreen);


        mContentView = (GridView)findViewById(R.id.gridView);

        mContentView.setAdapter(new ImageGridAdapter(this));



        mContentView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);

    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mContentView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
    }
    public class ImageGridAdapter extends BaseAdapter {
        private final Activity activity;
        private final int[] rIcon = {
                R.drawable.top002
                , R.drawable.top003
                , R.drawable.top004
                ,R.drawable.billboard
                , R.drawable.music002
        };

        public ImageGridAdapter(Activity activity) {
            this.activity = activity;
        }

        @Override
        public int getCount() {
            return rIcon.length;
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageView;
            if( convertView == null ){
                imageView = new ImageView(activity);
                imageView.setLayoutParams(new GridView.LayoutParams(400,350));
                imageView.setScaleType(ImageView.ScaleType.CENTER);
                imageView.setPadding(5, 5, 5, 5);
            }else{
                imageView = (ImageView) convertView;
            }

            imageView.setImageResource(rIcon[position]);

            return imageView;
        }

    }




}
