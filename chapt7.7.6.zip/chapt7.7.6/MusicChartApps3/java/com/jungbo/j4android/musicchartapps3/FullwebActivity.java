package com.jungbo.j4android.musicchartapps3;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class FullwebActivity extends AppCompatActivity {

    /**
     * Whether or not the system UI should be auto-hidden after
     * {@link #AUTO_HIDE_DELAY_MILLIS} milliseconds.
     */
    private static final boolean AUTO_HIDE = true;

    /**
     * If {@link #AUTO_HIDE} is set, the number of milliseconds to wait after
     * user interaction before hiding the system UI.
     */
    private static final int AUTO_HIDE_DELAY_MILLIS = 3000;

    /**
     * Some older devices needs a small delay between UI widget updates
     * and a change of the status and navigation bar.
     */
    private static final int UI_ANIMATION_DELAY = 300;
    private final Handler mHideHandler = new Handler();

    private WebView mContentView;

    private ImageButton btnHome;
    private ImageButton btnLeft;
    private ImageButton btnRight;
    private ImageView imageView;
    private String activityID="1";
    private String activityURL="";
    private String nowMenuURL="";
    private ProgressDialog progressDialog;
    BillboardRequestAsync bill;
    Billboard200RequestAsync bill200;
    BillboardArtistRequestAsync billartist;
    private final Runnable mHidePart2Runnable = new Runnable() {
        @SuppressLint("InlinedApi")
        @Override
        public void run() {
            // Delayed removal of status and navigation bar

            // Note that some of these constants are new as of API 16 (Jelly Bean)
            // and API 19 (KitKat). It is safe to use them, as they are inlined
            // at compile-time and do nothing on earlier devices.
            mContentView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        }
    };
    private final Runnable mShowPart2Runnable = new Runnable() {
        @Override
        public void run() {
            // Delayed display of UI elements
            ActionBar actionBar = getSupportActionBar();
            if (actionBar != null) {
                actionBar.show();
            }
        }
    };
    private boolean mVisible=true;
    private final Runnable mHideRunnable = new Runnable() {
        @Override
        public void run() {
            hide();
        }
    };
    /**
     * Touch listener to use for in-layout UI controls to delay hiding the
     * system UI. This is to prevent the jarring behavior of controls going away
     * while interacting with activity UI.
     */
    private final View.OnTouchListener mDelayHideTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            Toast.makeText(getApplicationContext(), "touch", Toast.LENGTH_LONG).show();
            if (AUTO_HIDE) {
                delayedHide(AUTO_HIDE_DELAY_MILLIS);
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_fullweb);

        mVisible = true;
        mContentView = (WebView)findViewById(R.id.fullscreen_content);
       // toggle();

        // Set up the user interaction to manually show or hide the system UI.
        mContentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggle();
            }
        });


        WebSettings webSettings=mContentView.getSettings();
        mContentView.setWebViewClient(new ActivatingWebViewClient());


        mContentView.getSettings().setJavaScriptEnabled(true);
        mContentView.addJavascriptInterface(new JavaScriptExtention(), "android");

        bill=new BillboardRequestAsync(this);
        bill200=new Billboard200RequestAsync(this);
        billartist=new BillboardArtistRequestAsync(this);

        //mContentView.setVerticalScrollbarOverlay(true);
        btnHome = (ImageButton)findViewById(R.id.btn_home);
        btnLeft = (ImageButton)findViewById(R.id.btn_pre);
        btnRight = (ImageButton)findViewById(R.id.btn_next);


        // 타이틀 세팅, URL세팅
        Intent intent = getIntent();
        activityID = intent.getStringExtra("activityID");
        activityURL = ChartUtil.getActivityId(activityID);

        if(activityID.equals("5")){
            bill.execute();
        }else if(activityID.equals("6")){
            bill200.execute();
        }else if(activityID.equals("7")){
            billartist.execute();
        }else{
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        mContentView.loadUrl(activityURL);
                    } catch (Exception e) {
                    }
                }
            }, 300);
        }

        settingButton();

    }

    private void settingButton() {
        btnHome.setOnClickListener(onClickListener);
        btnLeft.setOnClickListener(onClickListener);
        btnRight.setOnClickListener(onClickListener);
    }
    public String tourl(String msg){
        msg=msg.replaceAll("'","_A_");
        return msg=msg.replaceAll(" ","+");
    }
    public String tourl2(String msg){
       msg=msg.replaceAll("_A_","%27");
       return msg;
    }
public String apos(String msg){
    return "'"+msg+"'";
}

    public void updateResult(ArrayList<Billbaord> result) {
        final  StringBuffer sb=new StringBuffer();
        sb.append("<br/><div align='center'><h3>Billboard Hot 100</h3>"+bill.getTimedate());
sb.append("<table>");
        sb.append("<col width='10%'/>");
        sb.append("<col width='60%'/>");
        sb.append("<col width='auto'/>");
        int countw=0;
        for(Billbaord billb:result){
            sb.append("<tr>");
            sb.append("<td>"+ ++countw +"</td>");
            sb.append("<td onclick=\"window.android.goLastTrack("+apos(tourl(billb.getArtist()))+","
                    +apos(tourl(billb.getSong()))+");\">");
            sb.append(billb.getSong());sb.append("<br/>");
            sb.append("<font style='font-size:9px;color:#09a0cc'>"+billb.getArtist()+"</font>");
            sb.append("</td>");
            sb.append("<td onclick=\"window.android.goLastFm("+apos(tourl(billb.getArtist()))+");\">");
            sb.append("<img src="+apos(billb.getImagesrc())+" width='75px' height='50px' alt='No Image'/>");
            sb.append("</td>");
            sb.append("</tr>");
        }
        sb.append("<tr><td>&nbsp;</td></tr>");
        sb.append("<tr><td>&nbsp;</td></tr>");
        sb.append("</table></div>");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    mContentView.loadData(sb.toString(), "text/html", "utf-8");
                } catch (Exception e) {
                }
            }
        }, 300);
    }
    public void updateResult2(ArrayList<Billbaord> result) {
        final  StringBuffer sb=new StringBuffer();
        sb.append("<br/><div align='center'><h3>Billboard Chart (Album) 200</h3>"+bill200.getTimedate());
        sb.append("<table>");
        sb.append("<col width='10%'/>");
        sb.append("<col width='60%'/>");
        sb.append("<col width='auto'/>");
        int countw=0;
        for(Billbaord billb:result){
            sb.append("<tr>");
            sb.append("<td>"+ ++countw +"</td>");
            sb.append("<td onclick=\"window.android.goLastTrack("+apos(tourl(billb.getArtist()))+","
                    +apos(tourl(billb.getSong()))+");\">");
            sb.append(billb.getSong());sb.append("<br/>");
            sb.append("<font style='font-size:9px;color:#09a0cc'>"+billb.getArtist()+"</font>");
            sb.append("</td>");
            sb.append("<td onclick=\"window.android.goLastFm("+apos(tourl(billb.getArtist()))+");\">");
            sb.append("<img src="+apos(billb.getImagesrc())+" width='75px' height='50px' alt='No Image'/>");
            sb.append("</td>");
            sb.append("</tr>");
        }
        sb.append("<tr><td>&nbsp;</td></tr>");
        sb.append("<tr><td>&nbsp;</td></tr>");
        sb.append("</table></div>");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    mContentView.loadData(sb.toString(), "text/html", "utf-8");
                } catch (Exception e) {
                }
            }
        }, 300);
    }



    private final Handler handler = new Handler();

    public void updateResult3(ArrayList<Billbaord> result) {
        final  StringBuffer sb=new StringBuffer();
        sb.append("<br/><div align='center'><h3>Billboard Greatest Artists</h3>");
        sb.append("<table>");
        sb.append("<col width='10%'/>");
        sb.append("<col width='60%'/>");
        sb.append("<col width='auto'/>");
        int countw=0;
        for(Billbaord billb:result){
            sb.append("<tr>");
            sb.append("<td>"+ ++countw +"</td>");
            sb.append("<td onclick=\"window.android.goLastFm("+apos(tourl(billb.getArtist()))+");\">");
            sb.append(billb.getArtist());sb.append("<br/>");
            sb.append("<font style='font-size:9px;color:#09a0cc'>"+billb.getArtist()+"</font>");
            sb.append("</td>");
            sb.append("<td onclick=\"window.android.goLastFm("+apos(tourl(billb.getArtist()))+");\">");
            sb.append("<img src="+apos(billb.getImagesrc())+" width='75px' height='50px' alt='No Image'/>");
            sb.append("</td>");
            sb.append("</tr>");
        }
        sb.append("<tr><td>&nbsp;</td></tr>");
        sb.append("<tr><td>&nbsp;</td></tr>");
        sb.append("</table></div>");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    mContentView.loadData(sb.toString(), "text/html", "utf-8");
                } catch (Exception e) {
                }
            }
        }, 300);
    }



    final class JavaScriptExtention{
        JavaScriptExtention(){}
        @JavascriptInterface
          public void goLastFm(final String fm){
            Log.d("FullwebActivity", "**************************     "+"http://www.last.fm/music/" + tourl2(fm) );
            handler.post(new Runnable() {
                public void run() {
                    Log.d("android", "-----------------------------------------------goLastFm(" + tourl2(fm) + ")");
                    mContentView.loadUrl("http://www.last.fm/music/" + tourl2(fm) );
                }
            });
        }
        @JavascriptInterface
        public void goLastTrack(final String fm, final String track){
            Log.d("FullwebActivity", "**************************     "+"http://www.last.fm/music/" + tourl2(fm) +"/_/"+tourl2(track));
            handler.post(new Runnable() {
                public void run() {
                    Log.d("android", "-----------------------------------------------goLastTrack(" + tourl2(fm) +","+tourl2(track)+ ")");
                    mContentView.loadUrl("http://www.last.fm/music/" + tourl2(fm) +"/_/"+tourl2(track) );
                }
            });
        }

    }

    public boolean useNetWork() {
        boolean isNetWork = false;
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null) { // connected to the internet
            if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                Log.d("FullwebActivity", "**************************                         ONLY-WIFI");
                isNetWork = true;
                Toast.makeText(getBaseContext(), activeNetwork.getTypeName(), Toast.LENGTH_SHORT).show();
            } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                Log.d("FullwebActivity", "**************************                         ONLY-3G");
                isNetWork = true;
                Toast.makeText(getBaseContext(), activeNetwork.getTypeName(), Toast.LENGTH_SHORT).show();
            }
        } else {
            // not connected to the internet
            isNetWork = false;
        }
        return isNetWork;
    }
    public void setAlertDialogUseInfo() {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("네트워크 테스트");
        b.setMessage("네트워크 없슴");
        b.setPositiveButton("네트워크확인요망", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        b.setNegativeButton("네트워크확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
            }
        });
        b.show();
    }
    private final View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch(v.getId()) {
                case R.id.btn_home :
                    Intent intent = new Intent(FullwebActivity.this, FullscreenActivity.class);
                    startActivity(intent);
                    break;
                case R.id.btn_pre :
                    if(mContentView.canGoBack()) {
                        if(useNetWork()) {
                            mContentView.goBack();
                        } else {
                            setAlertDialogUseInfo();
                        }
                    }
                    break;
                case R.id.btn_next :
                    if(mContentView.canGoForward()) {
                        if(useNetWork()) {
                            mContentView.goForward();
                        } else {
                            setAlertDialogUseInfo();
                        }
                    }
                    break;
                default: break;
            }
        }
    };

    public void setPreNextSendButton(String url) {
        if(mContentView.canGoBack()) {
            btnLeft.setBackgroundResource(R.drawable.left_on);
        } else {
            btnLeft.setBackgroundResource(R.drawable.left_off);
        }
        if(mContentView.canGoForward()) {
            btnRight.setBackgroundResource(R.drawable.right_on);
        } else {
            btnRight.setBackgroundResource(R.drawable.right_off);
        }
    }
    int count=1;
    final class ActivatingWebViewClient extends WebViewClient {
        public ActivatingWebViewClient() {
            progressDialog = ProgressDialog.show(FullwebActivity.this, "Parsing", "Parsing Billboard datas!");
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }
        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (progressDialog!=null )progressDialog.dismiss();
            nowMenuURL = url;
            setPreNextSendButton(nowMenuURL);
        }
    }

    public void setOptionMenu() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                openOptionsMenu();
            }
        }, 10);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {

        }
        if (newConfig.keyboardHidden == Configuration.KEYBOARDHIDDEN_NO) {

        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode==4) {
            if(mContentView.canGoBack()) {
                mContentView.goBack();
            } else {
                Intent intent = new Intent(FullwebActivity.this, FullscreenActivity.class);
                startActivity(intent);
            }
            return true;
        } else if(keyCode==82) {
        }
        return true;
    }

    public void requestKillProcess(final Context context) {
        int sdkVersion = Integer.parseInt(Build.VERSION.SDK);
        if (sdkVersion < 8) {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            am.restartPackage(getPackageName());
        } else {
            Intent intent2 = new Intent();
            intent2.setAction("android.intent.action.MAIN");
            intent2.addCategory("android.intent.category.HOME");
            intent2.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                    | Intent.FLAG_ACTIVITY_FORWARD_RESULT
                    | Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_PREVIOUS_IS_TOP
                    | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(intent2);
        }
    }

    public WebView getWebView() {
        return mContentView;
    }
    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        delayedHide(100);
    }

    private void toggle() {
        if (mVisible) {
            hide();
        } else {
            show();
        }
    }

    private void hide() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        mVisible = false;
        mHideHandler.removeCallbacks(mShowPart2Runnable);
        mHideHandler.postDelayed(mHidePart2Runnable, UI_ANIMATION_DELAY);
    }

    @SuppressLint("InlinedApi")
    private void show() {
        mContentView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        mVisible = true;
        mHideHandler.removeCallbacks(mHidePart2Runnable);
        mHideHandler.postDelayed(mShowPart2Runnable, UI_ANIMATION_DELAY);
    }
    private void delayedHide(int delayMillis) {
        mHideHandler.removeCallbacks(mHideRunnable);
        mHideHandler.postDelayed(mHideRunnable, delayMillis);
    }
}
