package com.infopub.j4android.billboardchartlist002;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class YoutubeWebViewActivity extends AppCompatActivity {
    Button btnBottom ;
    WebView webView;
    String st1=MusicUtil.YOUTUBESEARCH;
    public String tourl(String msg){
        return msg.replaceAll(" ","+");
    }
    public static String toArtis2(String msg){
        return msg.replaceAll(" ","-");
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        Intent intent=new Intent(this.getIntent());
        String artist=intent.getStringExtra("artist");
        String track=intent.getStringExtra("track");
        setTitle(toArtis2(artist)+"\'s Track");
        st1=st1+tourl(artist);
        Log.i("doInBackground","-----------------------------------------"+st1);
        btnBottom =(Button) findViewById(R.id.btnBottom);
        btnBottom.setText(toArtis2(artist) +"\'s Track");
        btnBottom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webView.loadUrl(st1);
                webView.setWebViewClient(new WebViewClient());
            }
        });
        webView=(WebView)findViewById(R.id.webView);
        WebSettings webSettings=webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.loadUrl(st1);
        webView.setWebViewClient(new WebViewClient());
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
           finish();
        }
        return super.onOptionsItemSelected(item);
    }
    private class MyWebViewWebViewClient extends WebViewClient{
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return super.shouldOverrideUrlLoading(view, request);
        }
    }
}