package com.infopub.j4android.billboardchartlist002;

/**
 * Created by honeyjava on 2016-08-12.
 */
public class MusicUtil {

    public static String BILLBOARD = "https://www.billboard.com/charts/hot-100/";
    public static String YOUTUBESEARCH = "https://www.youtube.com/results?search_query=";
}
