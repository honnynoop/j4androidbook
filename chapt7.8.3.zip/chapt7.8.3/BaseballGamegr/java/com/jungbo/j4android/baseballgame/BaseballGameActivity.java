package com.jungbo.j4android.baseballgame;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class BaseballGameActivity extends AppCompatActivity implements View.OnClickListener{

    //member
    TextView tvTop;
    ImageButton b0;
    ImageButton b1;
    ImageButton b2;
    ImageButton b3;
    ImageButton b4;
    ImageButton b5;
    ImageButton b6;
    ImageButton b7;
    ImageButton b8;
    ImageButton b9;
    ImageButton bball;
    ImageButton bstrike;
    ImageButton rball;
    ImageButton rstrike;

    ImageButton bc;
    ImageButton bh;
    ImageButton bp;

    Umpire emp;//심판
    Hitter hit;//타자
    Pitcher pit;//투수
    //-----------------------
    int pressCount=0;//버튼 3개를 누름
    int iterCount=0;//10회내에 맞추기
    int [] ball;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baseball_game);
        // 초기화
        init();
        //이벤트처리
        addListener();
    }

    public void init(){
        tvTop= (TextView)this.findViewById(R.id.tvTop);
        bc = (ImageButton)this.findViewById(R.id.bc);
        bp = (ImageButton)this.findViewById(R.id.bp);
        bh = (ImageButton)this.findViewById(R.id.bh);
        b0 = (ImageButton)this.findViewById(R.id.b0);
        b1 = (ImageButton)this.findViewById(R.id.b1);
        b2 = (ImageButton)this.findViewById(R.id.b2);
        b3 = (ImageButton)this.findViewById(R.id.b3);
        b4 = (ImageButton)this.findViewById(R.id.b4);
        b5 = (ImageButton)this.findViewById(R.id.b5);
        b6 = (ImageButton)this.findViewById(R.id.b6);
        b7 = (ImageButton)this.findViewById(R.id.b7);
        b8 = (ImageButton)this.findViewById(R.id.b8);
        b9 = (ImageButton)this.findViewById(R.id.b9);
        bball = (ImageButton)this.findViewById(R.id.bball);
        bstrike = (ImageButton)this.findViewById(R.id.bstrike);
        rball = (ImageButton)this.findViewById(R.id.rball);
        rstrike = (ImageButton)this.findViewById(R.id.rstrike);
        setting(true);
        settingButton(false);
        //-------------------
        hit=new Hitter(3);
        pit=new Pitcher(3);
        emp=new Umpire(3);
    }

    public void addListener(){
        bc.setOnClickListener(this);
        bp.setOnClickListener(this);
        bh.setOnClickListener(this);

        b0.setOnClickListener(this);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);
        b6.setOnClickListener(this);
        b7.setOnClickListener(this);
        b8.setOnClickListener(this);
        b9.setOnClickListener(this);
        bball.setOnClickListener(this);
        rball.setOnClickListener(this);
        bstrike.setOnClickListener(this);
        rstrike.setOnClickListener(this);
    }

    //시작, 히팅 버튼을 보이거나 안보이게
    public void setting(boolean s){
        if(s){
            bp.setVisibility(View.VISIBLE);//play
            bc.setVisibility(View.INVISIBLE);//clear
            bh.setVisibility(View.INVISIBLE);//hitting
        }else{
            bp.setVisibility(View.INVISIBLE);//play
            bc.setVisibility(View.VISIBLE);//clear
            bh.setVisibility(View.VISIBLE);//hitting
        }
    }
    //번호버튼을 보이거나 안보이게
    public void settingButton(boolean s){
        if(s){
            b0.setVisibility(View.VISIBLE);//0
            b1.setVisibility(View.VISIBLE);//1
            b2.setVisibility(View.VISIBLE);//2
            b3.setVisibility(View.VISIBLE);//3
            b4.setVisibility(View.VISIBLE);//4
            b5.setVisibility(View.VISIBLE);//5
            b6.setVisibility(View.VISIBLE);//6
            b7.setVisibility(View.VISIBLE);//7
            b8.setVisibility(View.VISIBLE);//8
            b9.setVisibility(View.VISIBLE);//9
        }else{
            b0.setVisibility(View.INVISIBLE);//0
            b1.setVisibility(View.INVISIBLE);//1
            b2.setVisibility(View.INVISIBLE);//2
            b3.setVisibility(View.INVISIBLE);//3
            b4.setVisibility(View.INVISIBLE);//4
            b5.setVisibility(View.INVISIBLE);//5
            b6.setVisibility(View.INVISIBLE);//6
            b7.setVisibility(View.INVISIBLE);//7
            b8.setVisibility(View.INVISIBLE);//8
            b9.setVisibility(View.INVISIBLE);//9
        }
    }

    @Override
    //이벤트가 발생한 장소와 이벤트 내용을 담아서 넘긴다.
    public void onClick(View v) {
        //if(v.getId()==R.id.btnCancel){}
        if(v==bp){//시작을 누르면
            setting(false);
            settingButton(true);
            startGame();
            pressCount=0;//3개 버튼 누르기
            iterCount=0;//10번 안에 맞추기
            tvTop.setText("Base Ball Game!!");
            //btnResult1.setText("");
           //btnResult2.setText("");
            //btnResult3.setText("");

        }else if(v==bc){
            settingButton(true);
            pressCount=0;//3개 버튼 누르기
            //btnResult1.setText("");
            //btnResult2.setText("");
            //btnResult3.setText("");
        }else if(v==b0 && pressCount<3){
            setNums(0,b0);
        }else if(v==b1&& pressCount<3){
            setNums(1,b1);
        }else if(v==b2&& pressCount<3){
            setNums(2,b2);
        }else if(v==b3&& pressCount<3){
            setNums(3,b3);
        }else if(v==b4&& pressCount<3){
            setNums(4,b4);
        }else if(v==b5&& pressCount<3){
            setNums(5,b5);
        }else if(v==b6&& pressCount<3){
            setNums(6,b6);
        }else if(v==b7&& pressCount<3){
            setNums(7,b7);
        }else if(v==b8&& pressCount<3){
            setNums(8,b8);
        }else if(v==b9&& pressCount<3){
            setNums(9,b9);
        }else if(v==bh && pressCount==3){
            iterCount++;//히팅한 수--> 10번 이하에 맞추어야한다.
            hit.make(ball); //타자
            emp.setHit(hit.getBall());
            //-------------이곳 수정 요망
           // balllists.add(showHit());
            //lvResults.setAdapter(baseResult);

            //---------------
            if(iterCount<10){
                if(emp.strike()==3){
                    showHint3();
                    winGame();//win game
                }else{
                    showHint3();
                    contGame();//continue game
                }
            }else{
                showHint3();
                lostGame();//lost game
            }
        }
    }
    private void showHint3(){
        //showHint();
        //tvTop.setText(str);
        //showHit4();
        if(emp.strike()==0){
            rstrike.setImageResource(R.drawable.b0);
        }else if(emp.strike()==1){
            rstrike.setImageResource(R.drawable.b1);
        }else if(emp.strike()==2){
            rstrike.setImageResource(R.drawable.b2);
        }else if(emp.strike()==3){
            rstrike.setImageResource(R.drawable.b3);
        }
        if(emp.ball()==0){
            rball.setImageResource(R.drawable.b0);
        }else if(emp.ball()==1){
            rball.setImageResource(R.drawable.b1);
        }else if(emp.ball()==2){
            rball.setImageResource(R.drawable.b2);
        }else if(emp.ball() ==3){
            rball.setImageResource(R.drawable.b3);
        }

    }//
    private void showHint(){
        String str=String.format("%d Strike %d Ball!!",
                emp.strike(),emp.ball() );
        tvTop.setText(str);
    }//
    private String showHint2(){
        int[]mmm=pit.getBall();
        String st=String.format("[%d : %d : %d]",
                mmm[0],mmm[1],mmm[2] );
        return st;
    }
    private String showHit(){
        String str=String.format("%dS%dB",
                emp.strike(),emp.ball() );
        int[]mmm=hit.getBall();
        String st=String.format("%s:[%d:%d:%d]",
                str,mmm[0],mmm[1],mmm[2] );
        return st;
    }
    private String showHit4(){
        int[]mmm=hit.getBall();
        String st=String.format("[%d:%d:%d]%d회",mmm[0],mmm[1],mmm[2],iterCount );
        tvTop.setText(st);
        return st;
    }
    private void winGame(){
        tvTop.setText("축하합니다.("+iterCount+"회)");
        setting(true);
        settingButton(false);
        startGame();
        pressCount=0;//3개 버튼 누르기
        iterCount=0;//10번 안에 맞추기
    }
    //투수가 공을 던지고 심판에게 입력
    public void startGame(){
        pit.make();//서로 다른 세수 만들기->투수 공던지기
        ball=new int[3];//타자용 공 준비
        emp.setPit(pit.getBall());//심판에 넣기
    }
    private void lostGame(){
        tvTop.setText("Out! =>"+showHint2());
        setting(true);
        settingButton(false);
        startGame();
        pressCount=0;//3개 버튼 누르기
        iterCount=0;//10번 안에 맞추기
    }
    private void contGame(){
        showHit4();
        pressCount=0;//3개 버튼 누르기
        //iterCount++;
        settingButton(true);
    }
    private int toNum(String msg){
        return Integer.parseInt(msg.trim());
    }
    private int toNum(int msg){
        return  msg;
    }
    private void setNums(int number, ImageButton bu){
        if(pressCount>2){
            settingButton(false);
        }else{
            ball[pressCount]=number;
            if(pressCount==0){
                //btnResult1.setText(ball[pressCount]+"");
                //btnResult2.setText("");
                //btnResult3.setText("");
            }else if(pressCount==1){
                //btnResult2.setText(ball[pressCount]+"");
                //btnResult3.setText("");
            }else if(pressCount==2){
                //btnResult3.setText(ball[pressCount]+"");
            }
            bu.setVisibility(View.INVISIBLE);
            pressCount++;
        }
    }




}
