package com.jungbo.j4android.baseballgame;

public class Umpire {
	private int [] pit;
	private int [] hit;
	
	public Umpire(int m) {
		pit=new int[m];
		hit=new int[m];
	}
	public Umpire() {
		this(3);
	}
	public int[] getPit() {
		return pit;
	}
	public void setPit(int[] pit) {
		this.pit = pit;
	}
	public int[] getHit() {
		return hit;
	}
	public void setHit(int[] hit) {
		this.hit = hit;
	}
	//Strik
	public int strike(){
		int count=0;
		for (int i = 0; i < hit.length; i++) {
			if(hit[i]==pit[i]){count++;}
		}
		return count;
	}
	//ball
	public int ball(){
		int count=0;
		for (int i = 0; i < hit.length; i++) {
			for (int j = 0; j < hit.length; j++) {
				if( i!=j  && hit[i]==pit[j]){count++;}
			}
		}
		return count;
	}
}
