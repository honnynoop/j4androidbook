package com.infopub.j4android.j4amusicchartyoutube2;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class YoutubeWebViewActivity extends AppCompatActivity {
    Button btnBottom ;
    WebView webView;
    String st1="";
    String st2="";
    // String urls="http://www.last.fm/music";
    String urls="https://www.youtube.com/results?search_query=";

    String youtuberesult;

    public String tourl(String msg){
        return msg.replaceAll(" ","+");
    }
    public static String toArtis2(String msg){
        return msg.replaceAll(" ","-");
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_youtubeweb_view);

        Intent intent=new Intent(this.getIntent());
        String artist=intent.getStringExtra("artist");
        st1=artist;
        String track=intent.getStringExtra("track");
        setTitle(toArtis2(artist)+"\'s Track");
        Log.i("WebActivity","198-------------------------------------------------"+artist);

        webView=(WebView)findViewById(R.id.webView);
        WebSettings webSettings=webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        //수정
        String aaa=urls + tourl(artist) +"+"+tourl(track);
        webView.loadUrl(aaa);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
           finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private class MyWebViewWebViewClient extends WebViewClient{
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return super.shouldOverrideUrlLoading(view, request);
        }
    }

}