package com.infopub.j4android.j4amusicchartyoutube2;

/**
 * Created by honeyjava on 2016-08-12.
 */
public class MusicUtil {
    /*
    public static String toArtis(String msg){
        return msg.replaceAll("%+", " ");
    }
    */
    //자신의 APIKEY로 변경하세요.
    public static String APIKEY="cf887f978dccc5a68c06bb35b1b78319";
    public static String BILLBOARD="https://www.billboard.com/charts/hot-100/";
    public static String BILLBOARD200="https://www.billboard.com/charts/billboard-200/";
    public static String BILLBOARDARTIST="https://www.billboard.com/charts/greatest-billboard-200-artists";

    public static String FM="http://ws.audioscrobbler.com/2.0/";
    public static String FORMAT="&format=json";
    public static String METHOD1="?method=tag.gettoptracks";
    public static String METHOD2="?method=artist.gettoptracks";
    public static int LINE=50;
    public static String LIMIT="&limit="+LINE;
    public static String TAG="&tag=";
    public static String ARTIST="&artist=";
    public static String TOPTRACK=FM+METHOD1+FORMAT+LIMIT+"&api_key="+APIKEY+TAG;
    public static String TOPARTIST=FM+METHOD2+FORMAT+LIMIT+"&api_key="+APIKEY+ARTIST;

}
