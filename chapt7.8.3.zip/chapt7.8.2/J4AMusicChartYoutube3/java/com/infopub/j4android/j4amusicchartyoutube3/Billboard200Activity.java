package com.infopub.j4android.j4amusicchartyoutube3;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Billboard200Activity extends AppCompatActivity {

    ListView listView;
    BillboardAdapter lAdapter;
    ArrayList<Billbaord> tracks=new ArrayList<Billbaord>();
    private Button tracksButton;
    private Button btnBack;
    private TextView tv100;
    private  int num=0;
    private InputMethodManager inputMethodManager;
    private ImageListRequest ira;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_billboard);
        setTitle("BillBoard Chrat 200");
        this.inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        this.tracksButton = (Button)this.findViewById(R.id.btnToday);
        this.btnBack = (Button)this.findViewById(R.id.btnBack);
        this.tv100 = (TextView) this.findViewById(R.id.tv100);

        ira=new ImageListRequest();
        listView = (ListView) findViewById(R.id.listView);
        lAdapter=new BillboardAdapter(this,tracks,ira);
        listView.setAdapter(lAdapter);

        this.tracksButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                num=0;
                inputMethodManager.hideSoftInputFromWindow(tracksButton.getWindowToken(), 0);
                Billboard200RequestAsync lfmTask = new Billboard200RequestAsync(Billboard200Activity.this);
                try {
                    lfmTask.execute(num+"");
                } catch (Exception e) {
                    lfmTask.cancel(true);
                }

            }
        });
        this.btnBack.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                num++;
                inputMethodManager.hideSoftInputFromWindow(btnBack.getWindowToken(), 0);
                Billboard200RequestAsync lfmTask = new Billboard200RequestAsync(Billboard200Activity.this);
                try {
                    lfmTask.execute(num+"");
                } catch (Exception e) {
                    lfmTask.cancel(true);
                }

            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Billbaord eq = (Billbaord) parent.getItemAtPosition(position);
                String sf= String.format("artist:%s\'s %s",eq.getArtist(),eq.getSong());
                alert(sf);
            }

        });
    }
    public void alert (String msg)
    {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
    }
    @Override
    protected void onDestroy() {
        listView.setAdapter(null);
        super.onDestroy();
    }
    public void updateBillboard(ArrayList<Billbaord> tracks2, final String timedate) {
        this.tracks=tracks2;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                lAdapter.clear();
                lAdapter.addAll(tracks);
                lAdapter.notifyDataSetChanged();
                tv100.setText("Billboard HOT 200: "+timedate);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}


