package com.infopub.j4android.j4amusicchartyoutube3;

/**
 * Created by LG on 2016-09-11.
 */
public class ChartUtil {
    public  static String getActivityId(String id){
        if(id.equals("1")){
            return "http://www.last.fm/music";
        }else if(id.equals("2")){
            return "https://www.billboard.com/charts/hot-100";
        }else if(id.equals("3")){
            return "https://www.billboard.com/charts/billboard-200";
        }else if(id.equals("4")){
            return "https://www.billboard.com/charts/greatest-billboard-200-artists";
        }else if(id.equals("5")){
            return "http://www.last.fm/music/";
        }else{
            return "http://www.last.fm/music/micael+jackson/+tracks";
        }
    }//
}
