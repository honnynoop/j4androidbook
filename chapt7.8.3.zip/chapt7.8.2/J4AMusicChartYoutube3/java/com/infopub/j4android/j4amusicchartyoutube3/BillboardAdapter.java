package com.infopub.j4android.j4amusicchartyoutube3;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class BillboardAdapter extends ArrayAdapter<Billbaord> implements View.OnClickListener {
    Activity context;
   // Context context;
    ArrayList<Billbaord> tracks;
    ImageListRequest ira;
    public BillboardAdapter(Activity context, ArrayList<Billbaord> tracks, ImageListRequest ira) {
        super(context, R.layout.billboard_list_item, tracks);
        this.context = context;
        this.tracks = tracks;
        this.ira=ira;
    }
    public int getCount() {
        return tracks.size();
    }

    public Billbaord getItem(int position) {
        return tracks.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        try {
            final BillboardViewHolder holder;
            LayoutInflater
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            if (convertView != null) {
                holder = (BillboardViewHolder) convertView.getTag();
            } else {
                holder = new BillboardViewHolder(convertView = inflater.inflate(R.layout.billboard_list_item, null));
            }

            if(tracks.get(position).getArtist()!= null &&
                    !tracks.get(position).getArtist().trim().equals("")) {
                // modified
                Bitmap bmp = ira.loadImage(tracks.get(position).getImagesrc(),this);
                if(bmp != null) {
                    holder.imageview2.setImageBitmap(bmp);
                }else {
                    holder.imageview2.setImageResource(R.drawable.empty);
                }
            } else {
               holder.imageview2.setImageResource(R.drawable.empty);
            }
            convertView.setOnClickListener(this);
            //holder.artistUrl=tracks.get(position).getArtisturl();
           //; holder.imageview3.setImageResource(R.drawable.empty2);
           // holder.imageview3.setText(tracks.get(position).getArtisturl()+"");
            holder.imageview3.setText(tracks.get(position).getRank()+"");
           // holder.imageview3.setOnClickListener(this);
            holder.trackname.setText(tracks.get(position).getSong());
            holder.artistname.setText(tracks.get(position).getArtist());
            //String trackurls="http://www.last.fm/music/"+tourl(holder.artistname.getText()+"/_/"+tourl(holder.trackname.getText()+""));
            holder.trackurl.setText("");
            this.notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return convertView;
    }
    public String tourl(String msg){
        return msg.replaceAll(" ","+");
    }
    @Override
    public void onClick(View v) {
        BillboardViewHolder holder = (BillboardViewHolder) v.getTag();
       if (v instanceof View) {
           String basicurls=holder.artistname.getText()+"----"+holder.trackname.getText();
           alert(basicurls);
           Intent intent = new Intent(context,
                   YoutubeWebViewActivity.class);
                 //  WebViewActivity.class);
           intent.putExtra("artist",tourl(holder.artistname.getText().toString()));
           intent.putExtra("track",tourl(holder.trackname.getText().toString()));
           context.startActivity(intent);
        }
    }
    public void alert (String msg)
    {
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show();

    }
}

class BillboardViewHolder {
    // public String  artistUrl="";
    public ImageView imageview2;
    public TextView imageview3;
    public TextView trackname;
    public TextView artistname;
    public TextView trackurl;
    public BillboardViewHolder(View view) {
        imageview2 = (ImageView) view.findViewById(R.id.billImageView);
        imageview3 = (TextView) view.findViewById(R.id.billtxtRank);
        trackname = (TextView) view.findViewById(R.id.songname);
        artistname = (TextView) view.findViewById(R.id.artistname);
        trackurl = (TextView) view.findViewById(R.id.trackurl);
        view.setTag(this);
    }
}