package com.jungbo.j4android.googledistance02;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class GoogleMapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        showComponent();
    }
    public void showComponent(){
        //마커를 누르면 시간을 보여준다.
        mMap.setInfoWindowAdapter(new MapInfoWindowAdapter());
        //국가별 위도, 경도 설정
        LatLng seoul = new LatLng(37.5670, 126.9807);  //seoul 위도경도 설정
        LatLng austria = new LatLng(47.01, 10.2);  //austria 위도경도 설정
        LatLng newyork = new LatLng(40.714086, -74.228697);//newyork 위도경도 설정
        LatLng mexico = new LatLng(19.42847,-99.12766);//mexico 위도경도 설정
        LatLng china = new LatLng(39.9075,116.39723);//shanghai 위도경도 설정
        LatLng rusia = new LatLng(55.75222,37.61556);//rusia 위도경도 설정
        //국가별 위도, 경도, 타임존 아이디 대입
        addMyMarker(seoul,"Asia/Seoul");
        addMyMarker(austria,"Europe/Vienna");
        addMyMarker(newyork,"America/New_York");
        addMyMarker(mexico, "America/Mexico_City");
        addMyMarker(china,"Asia/Shanghai");
        addMyMarker(rusia, "Europe/Moscow");
        //일반 맵타입
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        //서울중심 세계전도
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(seoul, 1);
        mMap.animateCamera(update);

    }
    //위도,경도, 타임존 아이디를 마커에 반영
    public void addMyMarker(LatLng nation, String timezoneId){
        String nationtitle=String.format("%s%f,%f","",nation.latitude,nation.longitude);
        mMap.addMarker(new MarkerOptions().position(nation).title(nationtitle).snippet(timezoneId));
    }

    private class MapInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {
        private final View mInfoWindow;
        //사용자가 정의한 마커에 대한 레이아웃 생성
        public MapInfoWindowAdapter() {
            mInfoWindow = getLayoutInflater().inflate(R.layout.map_info_window, null);
        }
        @Override
        public View getInfoContents(Marker marker) {
            return null;
        }
        @Override
        public View getInfoWindow(Marker marker) {
            String timezoneId=marker.getSnippet();
           //사용자가 정의한 뷰
            ClockView cv=  (ClockView) mInfoWindow.findViewById(R.id.flagimage);
            cv.setTimezoneId(timezoneId);  //타입존 넣기 America/New_York
           //타이좀에 대한 시간을 가져온다.
            String title=String.format("%s [%s]",cv.getTimes(),marker.getTitle());
            //텍스트뷰에 시간을 보인다.
            TextView tvTitle = (TextView) mInfoWindow.findViewById(R.id.tvTitle);
            tvTitle.setText(title);
            //텍스트뷰에 타임존아이디를 보인다.
            TextView tvSnippet = (TextView) mInfoWindow.findViewById(R.id.tvSnippet);
            tvSnippet.setText(timezoneId);

            return mInfoWindow;
        }
    }
}
