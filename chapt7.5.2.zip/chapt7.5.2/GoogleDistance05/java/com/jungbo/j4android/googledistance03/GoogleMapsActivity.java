package com.jungbo.j4android.googledistance03;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.GeoApiContext;
import com.google.maps.PendingResult;
import com.google.maps.TimeZoneApi;

import java.util.TimeZone;

public class GoogleMapsActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMapLongClickListener {
    private GoogleMap mMap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        showComponent();
    }

    public void showComponent() {
        //마커를 누르면 시간을 보여준다.
        mMap.setInfoWindowAdapter(new MapInfoWindowAdapter());
        mMap.setOnMapLongClickListener(this); //이번트 등록

        //일반 맵타입
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        //서울중심 세계전도
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(new LatLng(37.5670, 126.9807), 1);
        mMap.animateCamera(update);
    }

    //위도,경도, 타임존 아이디를 마커에 반영
    public void addMyMarker(LatLng nation, String timezoneId) {
        // mMap.clear();
        String nationtitle = String.format("%f,%f", nation.latitude, nation.longitude);
        mMap.addMarker(new MarkerOptions().position(nation).title(nationtitle).snippet(timezoneId));
    }

    @Override
    public void onMapLongClick(final LatLng latLng) {

        GeoApiContext context = new GeoApiContext().setApiKey("AIzaSyBel-oNt50OFYfj1YpM0233xXlzuZVz34U");//본인의 API키를 입력하세요.
        //변환조심
        //com.google.android.gms.maps.model.LatLng ->com.google.maps.model.LatLng
        com.google.maps.model.LatLng mlatLng = new com.google.maps.model.LatLng(latLng.latitude, latLng.longitude);
        PendingResult<TimeZone> req = TimeZoneApi.getTimeZone(context, mlatLng);

        req.setCallback(new PendingResult.Callback<TimeZone>(){
            @Override
            public void onResult(final TimeZone result) {
                GoogleMapsActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        addMyMarker(latLng, result.getID());
                    }
                });
            }

            @Override
            public void onFailure(Throwable e) {
                Log.i("onFailure", "---------------------------" + e.toString());
            }
        } );
    }

    private class MapInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {
        private final View mInfoWindow;

        //사용자가 정의한 마커에 대한 레이아웃 생성
        public MapInfoWindowAdapter() {
            mInfoWindow = getLayoutInflater().inflate(R.layout.map_info_window, null);
        }

        @Override
        public View getInfoContents(Marker marker) {
            return null;
        }

        @Override
        public View getInfoWindow(Marker marker) {
            String timezoneId = marker.getSnippet();
            //사용자가 정의한 뷰
            ClockView cv = (ClockView) mInfoWindow.findViewById(R.id.flagimage);
            cv.setTimezoneId(timezoneId);  //타입존 넣기 America/New_York
            //타이좀에 대한 시간을 가져온다.
            String title = String.format("%s [%s]", cv.getTimes(), marker.getTitle());
            //텍스트뷰에 시간을 보인다.
            TextView tvTitle = (TextView) mInfoWindow.findViewById(R.id.tvTitle);
            tvTitle.setText(title);
            //텍스트뷰에 타임존아이디를 보인다.
            TextView tvSnippet = (TextView) mInfoWindow.findViewById(R.id.tvSnippet);
            tvSnippet.setText(timezoneId);
            return mInfoWindow;
        }
    }
}
