package com.jungbo.j4android.googledistance05;
import java.io.Serializable;

public class ClockCity implements Serializable{
    public double lat=37.5670;
    public double lng=126.9807;
    public String timezoneId="Asia/Seoul";
    public  String countryName="Korea";
    public String countryCode="KR";


}
