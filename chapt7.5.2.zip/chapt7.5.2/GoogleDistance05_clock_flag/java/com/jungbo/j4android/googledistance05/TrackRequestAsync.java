package com.jungbo.j4android.googledistance05;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.AsyncTask;
import android.os.Message;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class TrackRequestAsync extends AsyncTask<String, Void, ClockCity> {
	//String cityUrl  ="http://api.geonames.org/timezoneJSON";
	String cityUrl  = GeoID.GEO;
	Activity activity;
	ClockCity city;
	GoogleMapsActivity.RefreshViewHandler handler;
	ProgressDialog progressDialog;
	boolean isConnection=false;

	public ClockCity getCity() {
		return city;
	}

	public TrackRequestAsync(Activity ac, GoogleMapsActivity.RefreshViewHandler handler){
		super();
		activity = ac;
		city=new ClockCity(); //기본 서울
		this.handler=handler;
	}
	private String para(String key, String value){
		return String.format("&%s=%s",key,value);
	}
	private String parc(String key, String value){
		return String.format("?%s=%s",key,value);
	}
	@Override
	protected ClockCity doInBackground(String...params) {
		InputStream inputStream;
		String jsonString = "";
		String newUrls=cityUrl+ GeoID.id()+para("lat",params[0])+para("lng",params[1]);
		//String newUrls=cityUrl+ parc("username","xxxxxxxx")+para("lat",params[0])+para("lng",params[1]);
	try {
		Log.i("doInBackground", "---------------------------" + newUrls);
		URL url = new URL(newUrls);
		HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

		inputStream = new BufferedInputStream(urlConnection.getInputStream());
		BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
		StringBuilder sb = new StringBuilder();
		String line = null;
		while ((line = reader.readLine()) != null)
		{
			sb.append(line + "\n");
		}
		jsonString = sb.toString();
		Log.i("doInBackground", "---------------------------" + jsonString);
		inputStream.close();
		parseCityToJson(jsonString);

	} catch (IOException e) {
		Log.e("HTTP Request", e.getMessage());
		isConnection = false;

	} catch (JSONException je) {
		Log.e("JSON Parser", je.getMessage());
		isConnection = false;
	}
	return city;
}
	 @Override
	  protected void onPreExecute() {
		 super.onPreExecute();
		 progressDialog = ProgressDialog.show(activity, "Reading", "Reading Track datas!");
	  }
	@Override
	protected void onPostExecute(ClockCity result) {
		super.onPostExecute(result);
		if(isConnection) {
			if(activity instanceof GoogleMapsActivity){
				Message msg=Message.obtain();
				msg.what=1;
				msg.obj=result;   //String
				//handler.setLatLng(new LatLng(result.lat, result.lng));
				handler.sendMessage(msg);

				//((GoogleMapsActivity)activity).updateCity(result);
			}
			progressDialog.dismiss();
		} else {
			progressDialog.dismiss();
			AlertDialog.Builder adBuilder = new AlertDialog.Builder(activity);
			 
			adBuilder.setMessage("Check Http Track Connection and try again.")
				.setTitle("No Internet Access")
				.setPositiveButton("OK", new OnClickListener() {
			
					@Override
					public void onClick(DialogInterface dialog, int which) {
						return;
					}
				}).create();
			
			adBuilder.show();
		}
	}
	/*
http://api.geonames.org/timezoneJSON?lat=47.01&lng=10.2&username=demo
{
  "sunrise": "2016-10-03 07:21",
  "lng": 10.2,
  "countryCode": "AT",
  "gmtOffset": 1,
  "rawOffset": 1,
  "sunset": "2016-10-03 18:53",
  "timezoneId": "Europe/Vienna",
  "dstOffset": 2,
  "countryName": "Austria",
  "time": "2016-10-03 19:55",
  "lat": 47.01
}
	 */
	private synchronized void parseCityToJson(String json) throws JSONException {
		JSONObject jscity = new JSONObject(json);
		String timezoneId = jscity.getString("timezoneId");
		if(timezoneId==null || timezoneId.equals("")){
			isConnection=false;
		}else {
			String countryName = jscity.getString("countryName");
			double lng = jscity.getDouble("lng");
			double lat = jscity.getDouble("lat");
			String countryCode=jscity.getString("countryCode");
			//생성, 필통에 연필넣기
			city = new ClockCity(); //객체 생성
			city.countryName = countryName;
			city.lng = lng;
			city.lat = lat;
			city.timezoneId = timezoneId;
			city.countryCode=countryCode;
			isConnection=true;   //성공
		}
	}
}
/*
{
  "dstOffset": 0,
  "rawOffset": 32400,
  "status": "OK",
  "timeZoneId": "Asia/Seoul",
  "timeZoneName": "Korean Standard Time"
}
 */