package com.jungbo.j4android.googledistance05;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

public class FlagActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flag);

        Intent intent=new Intent(this.getIntent());

        String countryCode=intent.getStringExtra("countryCode");
        String timezoneId=intent.getStringExtra("timezoneId");

        ClockView cv = (ClockView) findViewById(R.id.flagimage);
        final ImageView imageVie=(ImageView) findViewById(R.id.imageView);

        cv.setTimezoneId(timezoneId);  //타입존 넣기 America/New_York

        //타이좀에 대한 시간을 가져온다.
        String title = String.format("%s [%s]", cv.getTimes(),timezoneId);
        //텍스트뷰에 시간을 보인다.
        TextView tvTitle = (TextView)findViewById(R.id.tvTitle);
        tvTitle.setText(title);
        //텍스트뷰에 타임존아이디를 보인다.
        TextView tvSnippet = (TextView)findViewById(R.id.tvSnippet);
        tvSnippet.setText(timezoneId );
        Log.i("flags", "---------countryCode--------------------------"+countryCode);


    }

}
