package com.jungbo.j4android.googledistance05;
/*
책 소스는 ID="demo"로 되어 있다. 사용하기전
회원 가입 http://www.geonames.org/login
*/
public class GeoID {
    public static final String GEO="http://api.geonames.org/timezoneJSON";
    private static String ID="honnynoop";    //이것을 반드시 변경해서 사용하세요.
    public static String id(){
        return "?username="+ID;
    }
    //https://maps.googleapis.com/maps/api/timezone/json?location=37.56,126.98&timestamp=1331161200&key=xxxxxxxxx
    /*
    {
        "dstOffset": 0,
            "rawOffset": 32400,
            "status": "OK",
            "timeZoneId": "Asia/Seoul",
            "timeZoneName": "Korean Standard Time"
    }*/
}
