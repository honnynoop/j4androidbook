package com.jungbo.j4android.googledistance05;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;

import java.io.IOException;
import java.net.URL;

public class UIUX {
    public static <T extends View> T findViewById(View view, int rid)      {
        return (T) view.findViewById(rid); }

    public static <T extends View> T findViewById(Activity activity, int rid)      {
        return (T) activity.getWindow().getDecorView().getRootView().findViewById(rid); }

    public static Bitmap toBitMap(Activity activity, String fname) throws IOException {
        Bitmap bitmap = BitmapFactory.decodeStream(activity.getResources().getAssets()
                .open(fname));
        return bitmap;
    }
    public static Bitmap toBitMap(String fname) throws IOException {
        URL url = null;
        Bitmap bmp = null;
        try {
            url = new URL(fname);
            bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
        } catch (Exception e) {
            throw e;
        }
        return bmp;
    }

}
