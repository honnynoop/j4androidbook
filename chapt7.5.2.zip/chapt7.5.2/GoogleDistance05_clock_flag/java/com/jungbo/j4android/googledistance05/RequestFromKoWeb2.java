package com.jungbo.j4android.googledistance05;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class RequestFromKoWeb2 {
	public static int IMAGESIZE=16*4;
	ArrayList<String> htmls=new ArrayList<String>();
	ArrayList<SovereignFlag> flags=new ArrayList<SovereignFlag>();
	
	public ArrayList<SovereignFlag> getFlags() {
		return flags;
	}

	public RequestFromKoWeb2() {
		htmls.clear();
		flags.clear();
	}

	boolean isConnection=false;

	public static String size(String name, int size){
		if(name.contains("px-Flag")){
			String prefix=name.substring(0,name.lastIndexOf("/")+1);
			String postfix=name.substring(name.lastIndexOf("/")+1);
			postfix=postfix.substring(postfix.indexOf("px-Flag"));
			//System.out.println(prefix+size+postfix);
			return prefix+size+postfix;
		}else return name;
	}


	public void getAllHtml(String newUrls){
		htmls.clear();
		InputStream inputStream;
		URL url=null;
		try {
			url= new URL(newUrls);
			HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
	
			inputStream = new BufferedInputStream(urlConnection.getInputStream());
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "utf-8"), 8);
	
			String line = null;
			while ((line = reader.readLine()) != null)
			{
				if(!line.trim().equals("")){

					htmls.add(line.trim());
				}
			}
			inputStream.close();
			isConnection=true;

		} catch (Exception e) {
			isConnection = false;
			System.out.println(e);
		} 
	}
	
	public String __toStr(String msg){
		return msg.replaceAll("_", " ");
	}
	public static String toname(String msg){
		String ss=msg;
		ss=ss.replaceAll("%27", "\'");
		ss=ss.replaceAll("%28", "(");
		ss=ss.replaceAll("%29", ")");
		ss=ss.replaceAll("%C3%B4", "o");
		ss=ss.replaceAll("%C3%85", "A");
		return ss.trim();
	}

	public synchronized void getSevereign(String msg){
		int count=0;
		flags.clear();
		for (int i=0; i<htmls.size(); i++) {
			String ss=htmls.get(i);
			if(ss.contains(msg)){     
				if(ss.contains(".svg.png")) {
					//String st=htmls.get(i+1);
					//System.out.println(ss);
					String korname = ss.substring(0, ss.lastIndexOf("</a></td>"));//
					korname = korname.substring(korname.lastIndexOf(">") + 1);//
					//System.out.println(korname);


					String flag = ss.substring(0, ss.lastIndexOf(".svg.png") + ".svg.png".length());//
					flag = "https:" + flag.substring(flag.lastIndexOf("//upload.wikimedia.org/wikipedia"));//
					//upload.wikimedia.org/wikipedia
					//System.out.println(national);
					flag = size(flag, IMAGESIZE);  //----size 선택

					String name = flag.substring(flag.lastIndexOf("/") + 1);
					name = name.substring(0, name.lastIndexOf(".svg.png"));//
					//System.out.println(nation);

					if (name.contains("Flag_of_the_")) {
						name = name.substring(name.lastIndexOf("Flag_of_the_") + "Flag_of_the_".length());//
					} else if (name.contains("Flag_of_The_")) {
						name = name.substring(name.lastIndexOf("Flag_of_The_") + "Flag_of_The_".length());//
					} else if (name.contains("Flag_of_")) {
						name = name.substring(name.lastIndexOf("Flag_of_") + "Flag_of_".length());//
					}
					name = toname(name);

					String code = htmls.get(i + 1);
					code = code.substring(0, code.lastIndexOf("<"));
					code = code.substring(code.indexOf(">") + 1);
					//System.out.println(code);
					//String shortname=htmls.get(i+2);
					String shortname = htmls.get(i + 3);//0927수정
					shortname = shortname.substring(0, shortname.lastIndexOf("<"));
					shortname = shortname.substring(shortname.indexOf(">") + 1);
//name=Ghana, shortname=GH, code=288, flag=https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Flag_of_Ghana.svg/44px-Flag_of_Ghana.svg.png, korname=가나
/*
	public double lat=37.5670;
    public double lng=126.9807;
    public String timezoneId="Asia/Seoul";
    public  String countryName="Korea";
    public String countryCode="KR";
					 */
					SovereignFlag sflag = new SovereignFlag(__toStr(name), shortname, code, flag);
					flags.add(sflag);
				}
			}
		}
	}
	

}
