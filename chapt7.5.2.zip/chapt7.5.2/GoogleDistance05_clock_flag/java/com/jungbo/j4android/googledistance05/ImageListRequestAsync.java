package com.jungbo.j4android.googledistance05;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Message;
import android.util.Log;

public class ImageListRequestAsync extends AsyncTask<String, Void, Bitmap> {
	ProgressDialog progressDialog;
	GoogleMapsActivity.MapInfoWindowAdapter.RefreshViewHandler2 handler2;
	Context activity;
	public ImageListRequestAsync(Context baseContext, GoogleMapsActivity.MapInfoWindowAdapter.RefreshViewHandler2 handler2) {
		this.activity=baseContext;
		this.handler2=handler2;
	}
	@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = ProgressDialog.show(activity, "Reading", "Reading Photo !");
		}
		@Override
		protected synchronized Bitmap doInBackground(String... params) {
			String ss = params[0];
			Bitmap bmp = null;
			try {
				bmp= UIUX.toBitMap(ss);
			} catch (Exception e) {
				Log.i("ImageRequestAsync","-------------ggggggggggggggggggggggggggggggggggggggggggggggggg------------");
			}
			return bmp;
		}

		@Override
		protected void onPostExecute(Bitmap bmp) {
			super.onPostExecute(bmp);
			if(bmp!=null) {
				Message msg=Message.obtain();
				msg.what=1;
				msg.obj=bmp;
				handler2.sendMessage(msg);
				progressDialog.dismiss();
			}else{
				progressDialog.dismiss();
			}
		}

}
