package com.jungbo.j4android.wikisovereignflagsapp1g;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
//(1) 아답터를 상속한다.
public class FlagsAdapterG extends ArrayAdapter<SovereignFlag> {
    //(4) 국가정보를 저장할 국가목록을 선언,생성한다.
    ArrayList<SovereignFlag> flags=new ArrayList<SovereignFlag>();
    Activity activity;
    //(5) 아답터는 액티버티와 레이아웃이 꼭 필요하다.
    public FlagsAdapterG (Activity activity, ArrayList<SovereignFlag> flags) {
        super(activity, R.layout.grid_flag_item, flags);  //아답터의 레이아웃 설정
        this.flags=flags;
        this.activity=activity;     //context를 통해서 inflate() 얻음
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {     //(2) 아이템화면에+국가정보
        //화면을 재사용하기 위한 객체
        FlagViewHolder flagViewHolder=null;
        //한국가의 정보
        SovereignFlag flag = flags.get(position);
        //(6) 아이템 화면을 담당하는 뷰
        View itemView = convertView;
        if (itemView == null) {  //(7) 아직 화면을 담당하는 뷰 객체가 생성되지 않았다면 화면 재활용객체를 준비하자.
            flagViewHolder = new FlagViewHolder();   //(8) 화면 재활용 객체
            itemView = activity.getLayoutInflater().inflate(R.layout.grid_flag_item, parent, false);
            flagViewHolder.imageView = (ImageView)itemView.findViewById(R.id.flagimage); //(9)이미지뷰 생성,
            flagViewHolder. flagname = (TextView) itemView.findViewById(R.id.flagname);
            flagViewHolder.flagshortname = (TextView) itemView.findViewById(R.id.flagshortname);
            itemView.setTag(flagViewHolder);     //(10) 화면담당 뷰객체에 홀더를 준비
        }else{
            flagViewHolder = (FlagViewHolder) itemView.getTag();   //(11)화면담당 뷰객체에서 홀더를 찾음
        }
        //(12) 재활용을 이용하여 화면에 데이터를 입력한다.
        flagViewHolder.imageView.setImageResource(flag.getRid());
        flagViewHolder. flagname.setText(flag.getName());
        flagViewHolder.flagshortname.setText(flag.getShortname());

        return itemView;
    }
}// FlagsAdapterG
//(3) 한 파일에 두 클래스를 선언할 때  파일명과 다른클래스는 public을 붙일 수 없다.
class FlagViewHolder{
    public ImageView imageView;
    public TextView flagname;
    public TextView flagshortname;
}
