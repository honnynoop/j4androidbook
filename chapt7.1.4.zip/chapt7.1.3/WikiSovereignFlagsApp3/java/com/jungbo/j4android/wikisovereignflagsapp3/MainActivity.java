package com.jungbo.j4android.wikisovereignflagsapp3;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    String where="srcset=\"//upload.wikimedia.org/wikipedia";
    ArrayList<SovereignFlag> manyflags=new ArrayList<SovereignFlag>();
    ListView list ;
    ImageView bigflag ;
    TextView textView;
    FlagsAdaptor<SovereignFlag> adapter;
    FlagListRequestAsync falgAsyn;
    private Menu menu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("국가 국기");
        //화면 UI객체 생성
        list = (ListView) findViewById(R.id.listView);
        bigflag = (ImageView) findViewById(R.id.bigflag);
        textView= (TextView) findViewById(R.id.textView);

        if(falgAsyn==null){
            falgAsyn=new FlagListRequestAsync(this);
            falgAsyn.execute(where);
        }

        adapter = new FlagsAdaptor<SovereignFlag>(this, manyflags);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View viewClicked,
                                    int position, long id) {

                SovereignFlag selectedflag = manyflags.get(position);
                String message =String.format("Sovereign is %s, Code is %s" +
                                " \n Korean name is %s, ",
                        selectedflag.getName(),selectedflag.getCode(),
                        selectedflag.getKorname());
                //이미지 가져오기
                ImageListRequestAsync ilra=new ImageListRequestAsync(MainActivity.this, handler);
                ilra.execute(selectedflag.getFlag());   //실행

                textView.setText(selectedflag.getKorname() + "  " + selectedflag.getShortname());
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }

    public RefreshViewHandler handler = new RefreshViewHandler();

    public class RefreshViewHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            Bitmap cc = (Bitmap)msg.obj;
            if(cc!=null && bigflag!=null){
                bigflag.setImageBitmap(cc);
            }
        }
    };

    public void readFlags(ArrayList<SovereignFlag> result) {
        manyflags.clear();
        manyflags=result;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                adapter.clear();
                adapter.addAll(manyflags);  //수정
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.menu = menu;

        getMenuInflater().inflate(R.menu.main_activity_actionbar, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.scan:
/*                falgAsyn=new FlagListRequestAsync(this);
                falgAsyn.execute(where);*/
                return true;
            case R.id.clear:
                //onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void onBackPressed() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle("Exit Application?");
        alertDialogBuilder
                .setMessage("Click yes to exit!")
                .setCancelable(false)
                .setPositiveButton("Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                moveTaskToBack(true);
                                android.os.Process.killProcess(android.os.Process.myPid());
                                System.exit(1);
                            }
                        })

                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        dialog.cancel();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
}
