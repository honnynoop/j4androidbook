package com.jungbo.j4android.wikisovereignflagsapp3;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Message;
import android.util.Log;

import java.net.URL;

public class ImageListRequestAsync extends AsyncTask<String, Void, Bitmap> {
	    ProgressDialog progressDialog;
	    MainActivity.RefreshViewHandler handler;
	    Context activity;
	    public ImageListRequestAsync(Context activity, MainActivity.RefreshViewHandler handler){
			this.activity=activity;
			this.handler=handler;
		}
	    @Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = ProgressDialog.show(activity, "Reading", "Reading Photo !");
		}
		@Override
		protected synchronized Bitmap doInBackground(String... params) {
			String ss = params[0];
			URL url = null;
			Bitmap bmp = null;
			try {
				url = new URL(ss);
				Log.i("ImageRequestAsync","-----------------------------------------"+ss);
				bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
			} catch (Exception e) {
				e.printStackTrace();
			}
			return bmp;
		}

		@Override
		protected void onPostExecute(Bitmap bmp) {
			super.onPostExecute(bmp);
			if(bmp!=null) {
				Message msg=Message.obtain();
				msg.what=1;
				msg.obj=bmp;
				handler.sendMessage(msg);
				progressDialog.dismiss();
			}else{
				progressDialog.dismiss();
			}
		}

}
