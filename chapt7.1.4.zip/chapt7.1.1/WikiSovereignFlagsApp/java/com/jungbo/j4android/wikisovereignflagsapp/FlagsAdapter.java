package com.jungbo.j4android.wikisovereignflagsapp;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class FlagsAdapter extends ArrayAdapter<SovereignFlag> {

    ArrayList<SovereignFlag> flags=new ArrayList<SovereignFlag>();
    Activity activity;
    public FlagsAdapter(Activity activity, ArrayList<SovereignFlag> flags) {
        super(activity, R.layout.list_flag_item, flags);  //아답터의 레이아웃 설정
        this.flags=flags;
        this.activity=activity;     //context를 통해서 inflate() 얻음
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        FlagViewHolder flagViewHolder=null;
        SovereignFlag flag = flags.get(position);
        View itemView = convertView;
        if (itemView == null) {  //
            flagViewHolder = new FlagViewHolder();   //화면 재활용 객체
            itemView = activity.getLayoutInflater().inflate(R.layout.list_flag_item, parent, false);
            flagViewHolder.imageView = (ImageView)itemView.findViewById(R.id.flagimage);
            flagViewHolder.flagkorname = (TextView) itemView.findViewById(R.id.flagkorname);
            flagViewHolder.flagcode = (TextView) itemView.findViewById(R.id.flagcode);
            flagViewHolder. flagname = (TextView) itemView.findViewById(R.id.flagname);
            flagViewHolder.flagshortname = (TextView) itemView.findViewById(R.id.flagshortname);
            itemView.setTag(flagViewHolder);
        }else{
            flagViewHolder = (FlagViewHolder) itemView.getTag();
        }
        //재활용을 이용하여 화면에 데이터를 입력한다.
        flagViewHolder.imageView.setImageResource(flag.getRid());
        flagViewHolder.flagkorname.setText(flag.getKorname());
        flagViewHolder. flagcode.setText(flag.getCode());
        flagViewHolder. flagname.setText(flag.getName());
        flagViewHolder.flagshortname.setText(flag.getShortname());

        return itemView;
    }
}//FlagsAdapter
//한 파일에 두 클래스를 선언할 때  파일명과 다른클래스는 public을 붙일 수 없다.
class FlagViewHolder{
    public ImageView imageView;
    public TextView flagkorname;
    public TextView flagcode;
    public TextView flagname;
    public TextView flagshortname;
}
