package com.jungbo.j4android.wikisovereignflagsapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<SovereignFlag> manyflags=new ArrayList<SovereignFlag>();
    ListView list ;
    ImageView bigflag ;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("국가 국기");
        //화면 UI객체 생성
        list = (ListView) findViewById(R.id.listView);
        bigflag = (ImageView) findViewById(R.id.bigflag);
        textView= (TextView) findViewById(R.id.textView);
        //국기 목록 만들기
        manyflags=readFlags();
        //압답터 만들고
        ArrayAdapter<SovereignFlag> adapter = new FlagsAdapter(this,manyflags);
        //리스트뷰에 아답터 설정
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View viewClicked,
                                    int position, long id) {

                SovereignFlag selectedflag = manyflags.get(position);
                String message = "You clicked position " + position
                        + " Sovereign is " + selectedflag.getName();
                //선택된 나라의 국기를 큰 화면에 보이기
                bigflag.setImageResource(selectedflag.getRid());
                //선택된 나라의 정보를 보임
                textView.setText(selectedflag.getKorname()+"  "+selectedflag.getShortname());

                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }

    public  ArrayList<SovereignFlag> readFlags(){
        ArrayList<SovereignFlag> flags=new ArrayList<SovereignFlag>();
        flags.clear();
        flags.add(new SovereignFlag("Ghana","GH","288","가나",R.drawable.gh));
        flags.add(new SovereignFlag("Gabon","GA","266","가봉",R.drawable.ga));
        flags.add(new SovereignFlag("Guyana","GY","328","가이아나",R.drawable.gy));
        flags.add(new SovereignFlag("Gambia","GM","270","감비아",R.drawable.gm));
        flags.add(new SovereignFlag("Guernsey","GG","831","건지 섬",R.drawable.gg));
        flags.add(new SovereignFlag("France","GP","312","과들루프",R.drawable.gp));
        flags.add(new SovereignFlag("Guatemala","GT","320","과테말라",R.drawable.gt));
        flags.add(new SovereignFlag("Guam","GU","316","괌",R.drawable.gu));
        flags.add(new SovereignFlag("Grenada","GD","308","그레나다",R.drawable.gd));
        flags.add(new SovereignFlag("Greece","GR","300","그리스",R.drawable.gr));
        flags.add(new SovereignFlag("Greenland","GL","304","그린란드",R.drawable.gl));
        flags.add(new SovereignFlag("Guinea","GN","324","기니",R.drawable.gn));
        flags.add(new SovereignFlag("Guinea-Bissau","GW","624","기니비사우",R.drawable.gw));
        flags.add(new SovereignFlag("Namibia","NA","516","나미비아",R.drawable.na));
        flags.add(new SovereignFlag("Nauru","NR","520","나우루",R.drawable.nr));
        flags.add(new SovereignFlag("Nigeria","NG","566","나이지리아",R.drawable.ng));
        flags.add(new SovereignFlag("Antarctica","AQ","010","남극",R.drawable.aq));
        flags.add(new SovereignFlag("South Sudan","SS","728","남수단",R.drawable.ss));
        flags.add(new SovereignFlag("South Africa","ZA","710","남아프리카 공화국",R.drawable.za));
        flags.add(new SovereignFlag("Netherlands","NL","528","네덜란드",R.drawable.nl));
        flags.add(new SovereignFlag("Netherlands Antilles (1986-2010)","AN","530","네덜란드령 안틸레스",R.drawable.an));
        flags.add(new SovereignFlag("Nepal","NP","524","네팔",R.drawable.np));
        flags.add(new SovereignFlag("Norway","NO","578","노르웨이",R.drawable.no));
        flags.add(new SovereignFlag("Norfolk Island","NF","574","노퍽 섬",R.drawable.nf));
        flags.add(new SovereignFlag("France","NC","540","누벨칼레도니",R.drawable.nc));
        flags.add(new SovereignFlag("New Zealand","NZ","554","뉴질랜드",R.drawable.nz));
        flags.add(new SovereignFlag("Niue","NU","570","니우에",R.drawable.nu));
        flags.add(new SovereignFlag("Niger","NE","562","니제르",R.drawable.ne));
        flags.add(new SovereignFlag("Nicaragua","NI","558","니카라과",R.drawable.ni));
        flags.add(new SovereignFlag("South Korea","KR","410","대한민국",R.drawable.kr));
        return flags;
    }
}
