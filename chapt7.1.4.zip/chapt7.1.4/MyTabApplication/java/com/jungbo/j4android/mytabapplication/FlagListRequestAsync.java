package com.jungbo.j4android.mytabapplication;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.AsyncTask;
import android.util.Log;

import java.util.ArrayList;

public class FlagListRequestAsync extends AsyncTask<String, Void, ArrayList<SovereignFlag>> {
	String flagsUrl="https://ko.wikipedia.org/wiki/ISO_3166-1";
	Activity activity;
	//ArrayList<String> artists;
	ProgressDialog progressDialog;
	boolean isConnection=false;
	ArrayList<SovereignFlag> flags=new ArrayList<SovereignFlag>();

	public ArrayList<SovereignFlag> getFlags() {
		return flags;
	}

	public FlagListRequestAsync(Activity ac){
		super();
		activity = ac;
		flags.clear();
		isConnection = true;
	}
	@Override
	protected ArrayList<SovereignFlag> doInBackground(String...params) {
		String where = params[0];

		RequestFromKoWeb2 rfw=new RequestFromKoWeb2();

		String a="https://ko.wikipedia.org/wiki/ISO_3166-1";
		//String msg="srcset=\"//upload.wikimedia.org/wikipedia";
		rfw.getAllHtml(a);
		rfw.getSevereign(where);
		flags=rfw.getFlags();
		Log.i("flags", "--------------flags---------------------------------------------------------" + flags.size());
/*
		for(SovereignFlag sfg: flags){
			ilr.loadImage(sfg.getFlag());
		}
*/
		//Log.i("doInBackground", "----------------xml------------------" + where);
		return flags;
	}


	 @Override
	  protected void onPreExecute() {
		 super.onPreExecute();
		 progressDialog = ProgressDialog.show(activity, "Reading", "Reading Flags datas!");
	  }
	
	@Override
	protected void onPostExecute(ArrayList<SovereignFlag> result) {
		super.onPostExecute(result);
		if(isConnection) {
			if(activity instanceof MainActivity){
				((MainActivity) activity).readFlags(result);
			}
			progressDialog.dismiss();
		} else {
			progressDialog.dismiss();
			AlertDialog.Builder adBuilder = new AlertDialog.Builder(activity);
			 
			adBuilder.setMessage("Check FileFlags Connection and try again.")
				.setTitle("No Internet Access")
				.setPositiveButton("OK", new OnClickListener() {
			
					@Override
					public void onClick(DialogInterface dialog, int which) {
						return;
					}
				}).create();
			
			adBuilder.show();
		}
	}
}
