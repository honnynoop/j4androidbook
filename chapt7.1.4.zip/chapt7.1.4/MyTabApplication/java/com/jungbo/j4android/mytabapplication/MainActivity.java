package com.jungbo.j4android.mytabapplication;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    String where="srcset=\"//upload.wikimedia.org/wikipedia";
    ArrayList<SovereignFlag> manyflags=new ArrayList<SovereignFlag>();
   // ListView list ;
    //ImageView bigflag ;
    //TextView textView;
    static  ImageListRequest ilr;
    FlagListRequestAsync falgAsyn;

    static int total=0;
    static int linePerPage=40;
    TabLayout tabLayout;

    private SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        if(falgAsyn==null){
            manyflags.clear();
            ilr=new ImageListRequest();
            falgAsyn=new FlagListRequestAsync(this);
            falgAsyn.execute(where);
        }else{
            readFlags(falgAsyn.getFlags());
        }
        tabLayout = (TabLayout) findViewById(R.id.tabs);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Tab "+curpage, Snackbar.LENGTH_LONG)
                        .setAction("Action", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Toast.makeText(MainActivity.this, "!!"+curpage, Toast.LENGTH_SHORT).show();
                            }
                        }).show();
            }
        });
    }


    public void readFlags(ArrayList<SovereignFlag> result) {
        total=result.size();
        this.manyflags=result;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
                mViewPager = (ViewPager) findViewById(R.id.container);
                mViewPager.setAdapter(mSectionsPagerAdapter);

                tabLayout.setupWithViewPager(mViewPager);
                mSectionsPagerAdapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {

        private static final String ARG_SECTION_NUMBER = "section_number";
        private  ArrayList<SovereignFlag> ssflags=new ArrayList<SovereignFlag>();

        public PlaceholderFragment( ) {
            ssflags.clear();
        }

        public  void setSsflags(ArrayList<SovereignFlag> ssflags) {
            this.ssflags = ssflags;
        }

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }
        public RefreshViewHandler handler = new RefreshViewHandler();

        public class RefreshViewHandler extends Handler {
            @Override
            public void handleMessage(Message msg) {
                Bitmap cc = (Bitmap)msg.obj;
                if(cc!=null && bigflag!=null){
                    bigflag.setImageBitmap(cc);
                }
            }
        };
        ImageView bigflag;
        ListView list;
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            final View rootView = inflater.inflate(R.layout.list_view, container, false);
            list = (ListView) rootView.findViewById(R.id.listView);
            bigflag= (ImageView) rootView.findViewById(R.id.bigflag);

            final  FlagsAdaptor<SovereignFlag>  adapter = new FlagsAdaptor<SovereignFlag>( this.getActivity(), ssflags);
            list.setAdapter(adapter);
            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View viewClicked,
                                        int position, long id) {

                    SovereignFlag selectedflag = ssflags.get(position);
                    String message = String.format("%s, %s",
                            selectedflag.getKorname(), selectedflag.getShortname());

                    ImageListRequestAsync ilra=new ImageListRequestAsync(PlaceholderFragment.this.getContext(), handler);
                    ilra.execute(selectedflag.getFlag());   //실행

                    TextView textView = (TextView) rootView.findViewById(R.id.textView);

                    textView.setText(message);
                }
            });
            return rootView;
        }

    }

    public   ArrayList<SovereignFlag> toSub(int position){
        int start=linePerPage*position;
        int end=linePerPage*(position+1)-1;
        if((int)(Math.ceil(1.0*total/linePerPage))==position+1){//마지막 tab
            if(total%linePerPage!=0){ //
                  end=total-1;
            }
        }
        List<SovereignFlag> subs2=manyflags.subList(start,end+1);
        ArrayList<SovereignFlag> arrays=new ArrayList<SovereignFlag>(subs2); //아래 소스와 동일
        // ArrayList<SovereignFlag> arrays=new ArrayList<SovereignFlag>();
        /*for (SovereignFlag sgf:subs2){
            arrays.add(sgf);
        }*/
        return arrays;
    }

    int curpage=0;

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }


        @Override
        public Fragment getItem(int position) {
            curpage=position;
            PlaceholderFragment place=PlaceholderFragment.newInstance(position + 1);
            place.setSsflags(toSub(position));
            return place;
        }

        @Override
        public int getCount() {
            return (int)(Math.ceil(1.0*total/linePerPage));
        }

        @Override
        public CharSequence getPageTitle(int position) {

            return "N"+(position+1);
        }
    }
}
