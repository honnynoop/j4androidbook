package com.jungbo.j4android.mytabapplication;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class FlagsAdaptor<T> extends ArrayAdapter<T> {

    ArrayList<T> flags=new ArrayList<T>();
    Activity activity;
    public FlagsAdaptor(Activity activity, ArrayList<T> flags) {
        super(activity, R.layout.list_flag_item, flags);
        this.flags=flags;
        this.activity=activity;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View itemView = convertView;
        if (itemView == null) {
            itemView = activity.getLayoutInflater().inflate(R.layout.list_flag_item, parent, false);
        }
        T t = flags.get(position);
        SovereignFlag flag= t instanceof SovereignFlag ? (SovereignFlag)t:null;
        if(flag!=null){

            TextView flagkorname = (TextView) itemView.findViewById(R.id.flagkorname);
            flagkorname.setText(flag.getKorname());


            TextView flagcode = (TextView) itemView.findViewById(R.id.flagcode);
            flagcode.setText(flag.getCode());


            TextView flagname = (TextView) itemView.findViewById(R.id.flagname);
            flagname.setText(flag.getName());

            TextView flagshortname = (TextView) itemView.findViewById(R.id.flagshortname);
            flagshortname.setText(flag.getShortname());
        }
        return itemView;
    }


}