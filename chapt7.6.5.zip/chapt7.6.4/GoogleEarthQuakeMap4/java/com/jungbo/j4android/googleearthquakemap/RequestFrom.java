package com.jungbo.j4android.googleearthquakemap;

import java.util.ArrayList;

/**
 * Created by HYJ on 2017-04-04.
 */
public interface RequestFrom {
    ArrayList<KREarthQuake> getKREarthQuakes();
    boolean isConnection();
    void getAllHtml(String newUrls);
    void getEarthQuakes(String msg);
}
