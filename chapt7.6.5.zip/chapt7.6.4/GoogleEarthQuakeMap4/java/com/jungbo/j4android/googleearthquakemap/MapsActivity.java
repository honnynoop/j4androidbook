package com.jungbo.j4android.googleearthquakemap;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    EarthQuakeRequestAsync async;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng seoul = new LatLng(37.56, 126.98);
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(seoul,6);
        mMap.animateCamera(update);

        Toast.makeText(this, "Ready~~~~", Toast.LENGTH_LONG).show();
        async =new EarthQuakeRequestAsync(this);
        String [] datas2=new String [] { "2015-01-01",todate2(new Date()),"3" ,"999"};
        async.execute(datas2);
    }

    public void updateResult(final ArrayList<KREarthQuake> result) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                for (KREarthQuake earth : result) {
                    double magnitude = earth.getMagnitude();
                    float makerColor = BitmapDescriptorFactory.HUE_CYAN;
                    LatLng loc = new LatLng(earth.getLatitude(), earth.getLongitude());
                    if (magnitude >= 7.0) {
                        makerColor = BitmapDescriptorFactory.HUE_RED;
                        earthCircle(mMap, loc, magnitude * 3000, Color.RED, 0xbaff0000);
                    }else if (magnitude >= 5.0) {
                        makerColor = BitmapDescriptorFactory.HUE_VIOLET;
                        earthCircle(mMap, loc, magnitude * 2000, 0xffa000a0, 0x9aff0000);
                    } else if (magnitude >= 4.0) {
                        makerColor = BitmapDescriptorFactory.HUE_BLUE;
                        earthCircle(mMap, loc, magnitude * 1500, Color.BLUE, 0x7aff0000);
                    } else if (magnitude >= 3.0) {
                        makerColor = BitmapDescriptorFactory.HUE_AZURE;
                        earthCircle(mMap, loc, magnitude * 1000, Color.YELLOW, 0x5a0000ff);
                    } else {
                        makerColor = BitmapDescriptorFactory.HUE_GREEN;
                        earthCircle(mMap, loc, magnitude * 500, Color.GREEN, 0x3a0000ff);
                    }
                    //if(earth.getTime().substring(0,10).equals("2016-09-12")){
                    /*
                    if (earth.getTime().substring(0, 7).equals(thisMonth(new Date()))
                            && earth.getMagnitude() >= 3.5) {
                        mMap.addMarker(new MarkerOptions().position(loc).title(earth.getLocation()).
                                icon(BitmapDescriptorFactory.defaultMarker(makerColor))).
                                setSnippet(magnitude + "/" + earth.getTime());
                    }
                    */
                }
            }
        });
    }
    //년도-월  2016-09 7자 문자열
    public  String thisMonth(Date dd){
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM");
        return sdf.format(dd);
    }
    //년도-월-일 2016-09-28
    public  String todate2(Date dd){
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(dd);
    }
    public void earthCircle(GoogleMap googleMap,  LatLng lat,double magni, int color,int fcolor ) {
        Circle circle = googleMap.addCircle(new CircleOptions()
                        .center(lat)
                        .radius(magni)
                        .strokeColor(color)
                        .fillColor(fcolor)
        );
    }
}
