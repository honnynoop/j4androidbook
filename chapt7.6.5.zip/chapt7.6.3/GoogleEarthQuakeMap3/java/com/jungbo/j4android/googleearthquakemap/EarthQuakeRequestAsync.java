package com.jungbo.j4android.googleearthquakemap;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.AsyncTask;

import java.util.ArrayList;

public class EarthQuakeRequestAsync extends AsyncTask<String, Void, ArrayList<KREarthQuake>> {

	Activity activity;
	ArrayList<KREarthQuake> kREarthQuakes=new ArrayList<KREarthQuake>();
	ProgressDialog progressDialog;
	boolean isConnection=false;

	RequestFromKMA rfw;         //웹에서 읽기

	public EarthQuakeRequestAsync(Activity ac){
		activity = ac;
	}
	@Override
	protected ArrayList<KREarthQuake> doInBackground(String...params) {
		getEarthQuakes();
		return kREarthQuakes;
	}

	 @Override
	  protected void onPreExecute() {
		 super.onPreExecute();
		 rfw=new RequestFromKMA();
		 progressDialog = ProgressDialog.show(activity, "Reading", "Reading Earthquake datas!");
	  }
	
	@Override
	protected void onPostExecute(ArrayList<KREarthQuake> result) {
		super.onPostExecute(result);
		if(isConnection) {
			if(activity instanceof MapsActivity) {
			((MapsActivity) activity).updateResult(result);  //지진정보를 화면에 반영
			}
			progressDialog.dismiss();
		} else {
			progressDialog.dismiss();
			AlertDialog.Builder adBuilder = new AlertDialog.Builder(activity);
			adBuilder.setMessage("Check Http Earthquake Connection and try again.")
				.setTitle("No Internet Access")
				.setPositiveButton("OK", new OnClickListener() {
			
					@Override
					public void onClick(DialogInterface dialog, int which) {
						return;
					}
				}).create();
			
			adBuilder.show();
		}
	}

	public  void getEarthQuakes() {
		kREarthQuakes.clear();
		rfw.getEarthQuakes();  //지진정보 가져오기
		isConnection = rfw.isConnection();  //성공적으로 가져왔는가
		kREarthQuakes = rfw.getKREarthQuake(); //지진정보를 저장
	}

}
