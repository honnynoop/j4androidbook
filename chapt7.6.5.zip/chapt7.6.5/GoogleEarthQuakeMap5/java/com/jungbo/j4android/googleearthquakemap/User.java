package com.jungbo.j4android.googleearthquakemap;

/**
 * Created by LG on 2016-10-06.
 */
public class User {
    public final static String USERNAME="honnynoop";
    public final static String GEOURL="http://api.geonames.org/earthquakesJSON";
}
