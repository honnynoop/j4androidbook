package com.jungbo.j4android.googleearthquakemap;

import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    EarthQuakeRequestAsync async;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng seoul = new LatLng(37.56, 126.98);
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(seoul,1);
        mMap.animateCamera(update);

        String[]datas={"90","-90","180","-180","5","500", todate2(new Date())};
        async =new EarthQuakeRequestAsync(this);
        async.execute(datas);
        Toast.makeText(this, "Ready~~~~", Toast.LENGTH_LONG).show();
    }

    public void updateResult(final ArrayList<Earthquake> result) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                for (Earthquake earth : result) {
                    double magnitude = earth.getMagnitude();
                    float makerColor = BitmapDescriptorFactory.HUE_CYAN;
                    LatLng loc = new LatLng(earth.getLatitude(), earth.getLongitude());
                    if (magnitude >= 8.0) {
                        makerColor = BitmapDescriptorFactory.HUE_RED;
                        earthCircle(mMap, loc, magnitude * 10000, Color.RED, 0xbaff0000);
                    } else if (magnitude >= 7.0) {
                        makerColor = BitmapDescriptorFactory.HUE_VIOLET;
                        earthCircle(mMap, loc, magnitude * 5000, Color.RED, 0x9aff0000);
                    } else if (magnitude >= 6.0) {
                        makerColor = BitmapDescriptorFactory.HUE_BLUE;
                        earthCircle(mMap, loc, magnitude * 3000, Color.BLUE, 0x7aff0000);
                    } else if (magnitude >= 5.0) {
                        makerColor = BitmapDescriptorFactory.HUE_AZURE;
                        earthCircle(mMap, loc, magnitude * 2000, Color.BLUE, 0x5aff0000);
                    } else {
                        makerColor = BitmapDescriptorFactory.HUE_GREEN;
                        earthCircle(mMap, loc, magnitude * 1000, Color.BLACK, 0x3aff0000);
                    }
                    /*
                    //if(earth.getTime().substring(0,10).equals("2016-09-12")){
                    String st = String.format("%.1f, %s", magnitude, earth.getDatetime());
                    //if (earth.getDatetime().trim().substring(0, 7).equals("2016-09")) {
                        if (earth.getDatetime().trim().substring(0, 7).equals(thisMonth(new Date()))) {
                        mMap.addMarker(new MarkerOptions().position(loc).title(st).
                                icon(BitmapDescriptorFactory.defaultMarker(makerColor))).
                                setSnippet( getLocation(loc) + "," + "depth : " + earth.getDepth());
                    }
*/
                }
            }
        });
    }
    public String  getLocation( LatLng loc) {
        return String.format("Lat: %s, Lng: %s", loc.latitude,loc.longitude);
    }
    public String  getLocation2( LatLng loc) {
        List<Address> addresses = null;
        Geocoder g = new Geocoder(this);
        String address="";
        try {
            addresses = g.getFromLocation(loc.latitude,loc.longitude, 1);
        } catch (Exception e) {
        }
        if(addresses != null && !addresses.isEmpty()) {
            address = getAddress(addresses.get(0),loc);
        }else {
            //바다와 같이 육지가 아닌곳
            address = String.format("Lat: %.4f, Lng: %.4f", loc.latitude,loc.longitude);
        }
        return address;
    }
    public String getAddress(Address address, LatLng loc) {
        if(address != null) {
            String add = address.getFeatureName();
            if(add == null)
                add = address.getLocality();
            if(add == null)
                add = address.getCountryName();
            if(add != null)
                return add;
        }
        return  String.format("Lat: %.4f, Lng: %.4f", loc.latitude,loc.longitude);
    }

    //년도-월  2016-09 7자 문자열
    public  String thisMonth(Date dd){
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM");
        return sdf.format(dd);
    }
    //년도-월-일 2016-09-28
    public  String todate2(Date dd){
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(dd);
    }
    public void earthCircle(GoogleMap googleMap,  LatLng lat,double magni, int color,int fcolor ) {
        Circle circle = googleMap.addCircle(new CircleOptions()
                        .center(lat)
                        .radius(magni)
                        .strokeColor(color)
                        .fillColor(fcolor)
        );
    }
}
