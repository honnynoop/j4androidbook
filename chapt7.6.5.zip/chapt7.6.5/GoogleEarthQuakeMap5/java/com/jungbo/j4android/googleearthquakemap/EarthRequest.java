package com.jungbo.j4android.googleearthquakemap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class EarthRequest {

	ArrayList<Earthquake> earthquakes=new ArrayList<Earthquake>();
    boolean isConnection=false;

	public boolean isConnection() {
    return isConnection;
  }

  public ArrayList<Earthquake> getEarthquakes() {
    return earthquakes;
  }

  public  void getEarth(String newUrls){
		InputStream inputStream;
		URL url=null;
		try {
			url = new URL(newUrls);
			HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
			inputStream = new BufferedInputStream(urlConnection.getInputStream());
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "utf-8"));
			StringBuilder sb = new StringBuilder();
			String line = null;
			//EOF 끝이 나올때까지 한 줄씩 읽어서
			while ((line = reader.readLine()) != null)
			{
				sb.append(line.trim());      //문자열을 붙임
			}
			inputStream.close();
			//json 파싱
			parseTrackToJson(sb.toString());
           isConnection=true;
		} catch (Exception e) {
          boolean isConnection=false;
			//System.out.println(e);
		} 
	}
	//지진 문자열을 json 파싱을 통해 지진객체로 만들고 지진목록을 완성
	private  void parseTrackToJson(String sjson) throws JSONException {
		earthquakes.clear();
		//지진문자열을 JSON 객체로 변경한다.
		JSONObject jObject = new JSONObject(sjson);
		JSONArray jArray = jObject.getJSONArray("earthquakes");
		try {
			for(int i=0; i<jArray.length(); i++) {
				JSONObject json=jArray.getJSONObject(i);
				Earthquake t=toEarth(json);
				earthquakes.add(t);  
			}
		} catch (JSONException e) {
			//e.printStackTrace();
		}
	}
	public  Earthquake toEarth(JSONObject json) throws JSONException{
		Earthquake earth=null;
		String eqid = json.getString("eqid");
		double magnitude = json.getDouble("magnitude");
		double longitude = json.getDouble("lng");
		double latitude = json.getDouble("lat");
		String source = json.getString("src");
		String datetime=json.getString("datetime");
		double depth = json.getDouble("depth");
		 earth=new Earthquake(
				eqid,magnitude,longitude,latitude,source,datetime,depth,"");
		return earth;
	}
}
