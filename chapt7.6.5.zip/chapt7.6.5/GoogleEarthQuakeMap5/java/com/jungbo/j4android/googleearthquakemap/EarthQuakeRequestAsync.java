package com.jungbo.j4android.googleearthquakemap;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.AsyncTask;
import android.util.Log;

import java.util.ArrayList;

public class EarthQuakeRequestAsync extends AsyncTask<String, Void, ArrayList<Earthquake>> {

	Activity activity;
	ArrayList<Earthquake> earthquakes=new ArrayList<Earthquake>();
	ProgressDialog progressDialog;
	boolean isConnection=false;

	EarthRequest rfw;

	public EarthQuakeRequestAsync(Activity ac){
		activity = ac;
	}
	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		rfw=new EarthRequest();
		progressDialog = ProgressDialog.show(activity, "Reading", "Reading Earthquake GEO Datas!");
	}
	@Override
	protected ArrayList<Earthquake> doInBackground(String...params) {
		getEarthQuakes(params);
		return earthquakes;
	}
	public  String para(String key, String value){
		return String .format("%s=%s",key,value);
	}

	public void getEarthQuakes(String...params){
		earthquakes.clear();
		//params={"90","-90","180","-180","6","300","2016-09-03"};
		String a=String.format("%s?%s%s%s%s%s%s%s%s",
				User.GEOURL,
				para("username",User.USERNAME),
				para("&north",params[0]),
				para("&south",params[1]),
				para("&east",params[2]),
				para("&west",params[3]),
				para("&minMagnitude",params[4]),
				para("&maxRows",params[5]),""
		//		para("&date",params[6])    //이것이 있으면 날짜순
		);
//http://api.geonames.org/earthquakesJSON?username=xxxx&north=90&south=-90&east=180&west=-180&minMagnitude=5&maxRows=500&date=2016-10-07
		Log.i("doInBackground", "-----------------------------------------------" + a);
		rfw.getEarth(a);   //파싱
		isConnection=rfw.isConnection();  //문자열을 정상적으로 읽었나
		earthquakes =rfw.getEarthquakes();//모든 지진목록
	}

	@Override
	protected void onPostExecute(ArrayList<Earthquake> result) {
		super.onPostExecute(result);
		if(isConnection) {
			if(activity instanceof MapsActivity) {
				((MapsActivity) activity).updateResult(result);
			}
			progressDialog.dismiss();
		} else {
			progressDialog.dismiss();
			AlertDialog.Builder adBuilder = new AlertDialog.Builder(activity);

			adBuilder.setMessage("Check Http Earthquake Connection and try again.")
					.setTitle("No Internet Access")
					.setPositiveButton("OK", new OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							return;
						}
					}).create();

			adBuilder.show();
		}
	}
}
