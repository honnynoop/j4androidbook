package com.jungbo.j4android.googledistance01;

import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class GoogleMapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private String otitle="Seoul";   // mMap 밑에 추가

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng seoul = new LatLng(37.5670, 126.9807);  //서울 위도경도 설정
        //otitle [seoul.latitude,seoul.longitude] 순서대로 입력
        String mytitle=String.format("%s [%f, %f]",otitle,seoul.latitude,seoul.longitude);
        mMap.addMarker(new MarkerOptions().position(seoul).title(mytitle));
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(seoul, 7);
        mMap.animateCamera(update);
        Toast.makeText(this, mytitle, Toast.LENGTH_LONG).show();
    }
}
