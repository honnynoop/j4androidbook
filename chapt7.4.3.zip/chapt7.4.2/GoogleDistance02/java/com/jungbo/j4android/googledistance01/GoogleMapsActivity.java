package com.jungbo.j4android.googledistance01;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class GoogleMapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    private double latitude=37.5670;
    private double longitude=126.9807;
    private String otitle="Seoul";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        //처음을 서울로 설정한다.
        LatLng seoul = new LatLng(latitude, longitude);  //서울 위도경도 설정
        showMap(seoul);
    }
    private void showMap(LatLng city) {
        String mytitle=String.format("%s [%f, %f]",otitle,city.latitude,city.longitude);
        mMap.addMarker(new MarkerOptions().position(city).title(mytitle.trim()));
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(city, 3);
        mMap.animateCamera(update);
        Toast.makeText(this, mytitle, Toast.LENGTH_LONG).show();
    }


}
